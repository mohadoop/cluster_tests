import cm_client
import time
from cm_client.rest import ApiException
from pprint import pprint
from jinja2 import Environment
from collections import namedtuple
from datetime import datetime
import os.path
import socket
import logging

logger = logging.getLogger('restart_mgmt')
logger.setLevel(logging.DEBUG)
"""
Cloudera Manager configurations
"""
cm_user = 'admin'
cm_pass = 'admin'
cm_api_version = 'v41'
tls=True
ca_cert_path = '/opt/cloudera/security/pki/rootCA.pem'
cluster_name = 'CDP_cluster_0701_3'



def setup_api():
    """
    Helper to set up the Cloudera Manager API
    This assumes that you are executing this script on the 
    Cloudera Manager host
    :return: api_client
    """
    cm_host = socket.gethostname()
    cm_client.configuration.username = cm_user
    cm_client.configuration.password = cm_pass
    if tls:
        logging.info('Setting up with TLS true')
        cm_client.configuration.verify_ssl = tls
        cm_client.configuration.ssl_ca_cert = ca_cert_path
        api_host = 'https://{host}'.format(host=cm_host)
        api_url = api_host + ':7183/api/' + cm_api_version
    else:
        logging.info("TLS is not enabled")
        api_host = 'http://{host}'.format(host=cm_host)
        api_url = api_host + ':7180/api/' + cm_api_version
        
    api_client = cm_client.ApiClient(api_url)
    return api_client

class ActiveCommands:
    def wait(self, cmd, timeout=None):
        SYNCHRONOUS_COMMAND_ID = -1
        if cmd.id == SYNCHRONOUS_COMMAND_ID:
            return cmd
        SLEEP_SECS = 5
        if timeout is None:
            deadline = None
        else:
            deadline = time.time() + timeout
        try:
            
            while True:
                cmd = cmd_api_instance.read_command(long(cmd.id))
                pprint(cmd)
                if not cmd.active:
                    return cmd
                if deadline is not None:
                    now = time.time()
                    if deadline < now:
                        return cmd
                    else:
                        time.sleep(min(SLEEP_SECS, deadline - now))
                else:
                    time.sleep(SLEEP_SECS)
        except ApiException as e:
            logging.error("Exception reading and waiting for command %s\n" %e)
            
class MngmtServices:
    def __init__(self):
        self._ac = ActiveCommands()
        
    def restart(self):
        try:
            cmd = api_instance.restart_command()
            self._ac.wait(cmd, 120)
        except ApiException as e:
            print("Exception when calling MgmtServiceResourceApi->restart_command: %s\n" % e)

if __name__ == '__main__':
    api_client = setup_api()
    cmd_api_instance = cm_client.CommandsResourceApi(api_client)
    api_instance = cm_client.MgmtServiceResourceApi(api_client)
    mgmnt=MngmtServices()
    mgmnt.restart()