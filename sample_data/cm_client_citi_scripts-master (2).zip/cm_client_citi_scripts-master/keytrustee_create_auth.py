import platform
import sys
import shlex
from subprocess import Popen, PIPE
import json

org_name='tkreutzer-cloudera'

class SubprocessCommandError(Exception):
    """An error code was returned while running the subprocess!"""

def exec_command(cmd):
    process = Popen(shlex.split(cmd), stdout=PIPE)
    out, err = process.communicate()
    exit_code = process.wait()
    print("Exit code: {exit_code}".format(exit_code=exit_code))
    if exit_code != 0:
        raise SubprocessCommandError
    return out


if __name__ == '__main__':
    print("Creating keytrustee auth")
    
    add_org_cmd='keytrustee-orgtool add -n {org_name} -c root@localhost'.format(org_name=org_name)
    exec_command(add_org_cmd)