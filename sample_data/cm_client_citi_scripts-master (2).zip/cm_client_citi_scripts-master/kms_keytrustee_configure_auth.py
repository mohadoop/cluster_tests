import platform
import sys
import shlex
from subprocess import Popen, PIPE
import json
import cm_client, random
from cm_client.rest import ApiException
from pprint import pprint
import logging
from logging import error

log = logging.getLogger('kms')
log.setLevel(logging.DEBUG)

cm_user = 'admin'
cm_pass = 'admin'
cm_api_version = 'v41'
cluster_name = 'CDP_cluster_0701_3'
tls=True
cm_host='ccycloud-1.tkreutzer.root.hwx.site'
ca_cert_path = '/opt/cloudera/security/pki/rootCA.pem'

org_name='tkreutzer-cloudera'


class SubprocessCommandError(Exception):
    """An error code was returned while running the subprocess!"""
def setup_api():
    """
    Helper to set up the Cloudera Manager API
    This assumes that you are executing this script on the 
    Cloudera Manager host
    :return: api_client
    """
    global cm_api_version
    cm_client.configuration.username = cm_user
    cm_client.configuration.password = cm_pass
    if tls:
        logging.info('Setting up with TLS true')
        cm_client.configuration.verify_ssl = tls
        cm_client.configuration.ssl_ca_cert = ca_cert_path
        api_host = 'https://{host}'.format(host=cm_host) + ':7183'
        api_url = api_host + '/api/' + cm_api_version
    else:
        logging.info("TLS is not enabled")
        api_host = 'http://{host}'.format(host=cm_host) + ':7180'
        api_url = api_host + '/api/' + cm_api_version
        
    api_client = cm_client.ApiClient(api_url)
    return api_client

def exec_command(cmd):
    process = Popen(shlex.split(cmd), stdout=PIPE)
    out, err = process.communicate()
    exit_code = process.wait()
    print("Exit code: {exit_code}".format(exit_code=exit_code))
    if exit_code != 0:
        raise SubprocessCommandError
    return out

def get_clusters():
    logging.debug("Getting clusters")
    try:
        return clusters_api_instance.read_clusters()
    except ApiException as e:
        print("Exception when calling ClustersResourceApi->read_clusters: %s\n" % e)
        
def get_services(cluster_name):
    try:
        return services_api_instance.read_services(cluster_name) #Cluster Name
    except ApiException as e:
        print("Exception when calling ServicesResourceApi->read_services: %s\n" % e)

def find_service(service_type_search):
    clusters = get_clusters()
    for cluster in clusters.items:
        print("Cluster Name: " + cluster.name)
        services = get_services(cluster.name)
        for service in services.items:
            print("Service Type: " + service.type)
            if service.type == service_type_search:
                log.info("Found cluster {c} with {st}".format(c=cluster.name, st=service_type_search))
                return service

def get_roles(cluster_name, service_name):
    log.info("Attempting to read_roles from the cluster {c} and the service name {s}".format(c=cluster_name, s=service_name))
    try:
        return roles_api_instance.read_roles(cluster_name, service_name)
    except ApiException as e:
        print("Exception when calling RolesResourceApi->read_roles: %s\n" % e)
        
def read_role_config_groups(cluster_name, service_name):
    try:
        return role_config_group_api_instance.read_role_config_groups(cluster_name, service_name)
    except ApiException as e:
        print("Exception when calling RoleConfigGroupsResourceApi->read_role_config_groups: %s\n" % e)



def update_kms_with_kts_conf(auth_secret, org_name, keytrustee_service, kms_service):
    kms_rcgs = read_role_config_groups(kms_service.cluster_ref.cluster_name, kms_service.name)
    keytrustee_roles = get_roles(keytrustee_service.cluster_ref.cluster_name, keytrustee_service.name)
    for keytrustee_role in keytrustee_roles.items:
        configs =[]
        if keytrustee_role.type =="DB_ACTIVE":
            for r in kms_rcgs.items:
                configs.append(cm_client.ApiConfig(name='cloudera_trustee_keyprovider_hostname-ACTIVE', value=keytrustee_role.host_ref.hostname))
                configs.append(cm_client.ApiConfig(name='cloudera_trustee_keyprovider_auth', value=auth_secret))
                configs.append(cm_client.ApiConfig(name='cloudera_trustee_keyprovider_org', value=org_name))
                handle_role_configs(configs,
                                    kms_service.name,
                                    r.name,
                                    r.service_ref.cluster_name)
        elif keytrustee_role.type =="DB_PASSIVE":
            for r in kms_rcgs.items:
                configs.append(cm_client.ApiConfig(name='cloudera_trustee_keyprovider_hostname-PASSIVE', value=keytrustee_role.host_ref.hostname))
                configs.append(cm_client.ApiConfig(name='cloudera_trustee_keyprovider_auth', value=auth_secret))
                configs.append(cm_client.ApiConfig(name='cloudera_trustee_keyprovider_org', value=org_name))
                handle_role_configs(configs,
                                    kms_service.name,
                                    r.name,
                                    r.service_ref.cluster_name)


def handle_role_configs(configs, service_ref_name, role_config_group_name, cluster_name):
    msg = 'Updating parameter(s) for {service_type} and role config group {rcg}'.format(service_type=service_ref_name, rcg=role_config_group_name)
    try:
        print(msg)
        body=cm_client.ApiConfigList(configs)
        role_config_group_api_instance.update_config(cluster_name=cluster_name,
                                                     role_config_group_name=role_config_group_name,
                                                     service_name=service_ref_name,
                                                     message=msg,
                                                     body=body)
    except ApiException as e:
        print("Exception when calling RoleConfigGroupsResourceApi->update_config: %s\n" % e)
                
if __name__ == '__main__':
    print("Configuring keytrustee auth in Cloudera Manager")
    api_client = setup_api()
    
    #Set up API instances
    role_config_group_api_instance = cm_client.RoleConfigGroupsResourceApi(api_client)
    clusters_api_instance = cm_client.ClustersResourceApi(api_client)
    services_api_instance = cm_client.ServicesResourceApi(api_client)
    roles_api_instance = cm_client.RolesResourceApi(api_client)
    
    #Get auth
    auth_info_cmd='keytrustee-orgtool list'
    auth_info=json.loads(exec_command(auth_info_cmd))
    auth_secret = auth_info[org_name]['auth_secret']
    
    #Find Services
    kms_service = find_service("RANGER_KMS_KTS")
    keytrustee_service = find_service("KEYTRUSTEE_SERVER")
    
    #Update Data
    update_kms_with_kts_conf(auth_secret, org_name, keytrustee_service, kms_service)

