from __future__ import print_function
import time
import cm_client
from cm_client.rest import ApiException
from pprint import pprint
import socket
from logging import error
import logging

logging.basicConfig()
logger = logging.getLogger('mgmt_srvc_tls')
logger.setLevel(logging.DEBUG)


cm_user = 'admin'
cm_pass = 'admin'
cm_api_version = 'v41'

#Required to be True if TLS is already enabled in CM and you are changing to a 
#Different path, if no TLS set false and leave ca_cert_path blank
tls=True
ca_cert_path = '/opt/cloudera/security/pki/rootCA.pem'

ssl_client_truststore_location='/usr/java/jdk1.8.0_232-cloudera/jre/lib/security/jssecacerts'
ssl_client_truststore_password='changeit'


"""
-------------------------------------------------------------------------------
  No Configuration required beyond this point
-------------------------------------------------------------------------------
"""

def setup_api():
    """
    Helper to set up the Cloudera Manager API
    This assumes that you are executing this script on the 
    Cloudera Manager host
    :return: api_client
    """
    cm_host = socket.gethostname()
    cm_client.configuration.username = cm_user
    cm_client.configuration.password = cm_pass
    if tls:
        logger.info('Setting up with TLS true')
        cm_client.configuration.verify_ssl = tls
        cm_client.configuration.ssl_ca_cert = ca_cert_path
        api_host = 'https://{host}'.format(host=cm_host)
        api_url = api_host + ':7183/api/' + cm_api_version
    else:
        logger.info("TLS is not enabled")
        api_host = 'http://{host}'.format(host=cm_host)
        api_url = api_host + ':7180/api/' + cm_api_version
        
    api_client = cm_client.ApiClient(api_url)
    return api_client

def cofigure_mgmt_services_tls(api_instance, ssl_client_truststore_location, ssl_client_truststore_password):
    configs = []
    configs.append(cm_client.ApiConfig(name='ssl_client_truststore_location', value=ssl_client_truststore_location))
    configs.append(cm_client.ApiConfig(name='ssl_client_truststore_password', value=ssl_client_truststore_password))
    
    message = 'Updating Management Services for TLS'
    body = cm_client.ApiServiceConfig(configs) # ApiServiceConfig | Configuration changes. (optional)
    
    try:
        api_instance.update_service_config(message=message, body=body)
    except ApiException as e:
        print("Exception when calling MgmtServiceResourceApi->update_service_config: %s\n" % e)


if __name__ == '__main__':
    api_client = setup_api()
    
    #Set up API instances
    api_instance = cm_client.MgmtServiceResourceApi(api_client)
    cofigure_mgmt_services_tls(api_instance,
                               ssl_client_truststore_location,
                               ssl_client_truststore_password)

