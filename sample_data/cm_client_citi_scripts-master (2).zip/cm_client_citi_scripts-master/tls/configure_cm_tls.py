
import cm_client
from cm_client.rest import ApiException
from pprint import pprint
import socket

cm_user = 'admin'
cm_pass = 'admin'
cm_api_version = 'v41'

#Required to be True if TLS is already enabled in CM and you are changing to a 
#Different path, if no TLS set false and leave ca_cert_path blank
tls=True
ca_cert_path = '/opt/cloudera/security/pki/rootCA.pem'

keystore_path='/opt/cloudera/security/pki/host_keystore.jks'
keystore_password='Cloudera123'
truststore_path='/opt/cloudera/security/pki/cluster_truststore.jks'
truststore_password='Cloudera123'
agent_tls=True
web_tls=True



"""
-------------------------------------------------------------------------------
  No Configuration required beyond this point
-------------------------------------------------------------------------------
"""

def setup_api():
    """
    Helper to set up the Cloudera Manager API
    This assumes that you are executing this script on the 
    Cloudera Manager host
    :return: api_client
    """
    cm_host = socket.gethostname()
    cm_client.configuration.username = cm_user
    cm_client.configuration.password = cm_pass
    if tls:
        logging.info('Setting up with TLS true')
        cm_client.configuration.verify_ssl = tls
        cm_client.configuration.ssl_ca_cert = ca_cert_path
        api_host = 'https://{host}'.format(host=cm_host)
        api_url = api_host + ':7183/api/' + cm_api_version
    else:
        logging.info("TLS is not enabled")
        api_host = 'http://{host}'.format(host=cm_host)
        api_url = api_host + ':7180/api/' + cm_api_version
        
    api_client = cm_client.ApiClient(api_url)
    return api_client


def setup_cm_tls(cm_api_instance,
                 keystore_path,
                 keystore_password,
                 truststore_path,
                 truststore_password,
                 agent_tls,
                 web_tls):
    configs = []
    configs.append(cm_client.ApiConfig(name='keystore_path', value=keystore_path))
    configs.append(cm_client.ApiConfig(name='keystore_password', value=keystore_password))
    configs.append(cm_client.ApiConfig(name='truststore_path', value=truststore_path))
    configs.append(cm_client.ApiConfig(name='truststore_password', value=truststore_password))
    configs.append(cm_client.ApiConfig(name='agent_tls', value=agent_tls))
    configs.append(cm_client.ApiConfig(name='web_tls', value=web_tls))
    message = 'Updating Cloudera Manager with TLS configurations'
    try: # Update the Cloudera Manager settings.
        cm_api_instance.update_config(message=message, body=cm_client.ApiConfigList(configs))
    except ApiException as e:
        logging.error("Exception when calling ClouderaManagerResourceApi->update_config: %s\n" % e)

if __name__ == '__main__':
    api_client = setup_api()
    
    #Set up API instances
    cm_api_instance = cm_client.ClouderaManagerResourceApi(api_client)
    setup_cm_tls(cm_api_instance,
                 keystore_path,
                 keystore_password,
                 truststore_path,
                 truststore_password,
                 agent_tls,
                 web_tls)





