############################################################################################################################################
# File Name: update_service_config.py
# Author: Thomas Kreutzer
# Date created: Aug 9, 2021
# Date last modified: Aug 9, 2021
# Python Version: 2.7.5
# CM Python API Version: 41
# Description: Following script is to be used to update a single configuration per call, generally to be used for passwords or other sensitive
#               parameters. This call is expected to be called and pass in the passwords to this script from Ansible. 
# Change Log
# Change Number | Date MM-DD-YYYY  | Changed By        | Change Description
# Initial       | 08-09-2021       | Thomas Kreutzer   | Initial code draft 
# 
#
# Values likely required to be updated with this script.
#
# FOR "serviceType": "RANGER", "refName": "ranger"
# rangeradmin_user_password
# rangerusersync_user_password
# ranger_database_password
# rangertagsync_user_password
# keyadmin_user_password
#
# FOR "serviceType": "HIVE", "refName": "hive"
# hive_metastore_database_password

# FOR "serviceType": "HUE", "refName": "hue"
# database_password
#
# FOR "serviceType": "SCHEMAREGISTRY", "refName": "schemaregistry"
# database_password
#
# FOR "serviceType": "STREAMS_MESSAGING_MANAGER", "refName": "streams_messaging_manager"
# smm_database_password
############################################################################################################################################

import socket
import sys
import cm_client
from cm_client.rest import ApiException
from collections import namedtuple
from pprint import pprint
from logging import error
import logging

logger = logging.getLogger('update_service_config')
logger.setLevel(logging.DEBUG)


"""
Cloudera Manager configurations
"""
cm_user = 'admin'
cm_pass = 'admin'
cm_api_version = 'v41'
tls=True
ca_cert_path = '/opt/cloudera/security/pki/rootCA.pem'
cluster_name = 'CDP_cluster_0701_3'

#configurations to be set with Ansible
service_type="{{ service_type }}"
service_ref_name="{{ service_ref_name }}"
service_config="{{ service_config }}"
service_value="{{ service_value }}"




"""
 No Configuration Required beyond this line
------------------------------------------------------------------------------------------
"""
services_api_instance=''

def setup_api():
    """
    Helper to set up the Cloudera Manager API
    This assumes that you are executing this script on the 
    Cloudera Manager host
    :return: api_client
    """
    cm_host = socket.gethostname()
    cm_client.configuration.username = cm_user
    cm_client.configuration.password = cm_pass
    if tls:
        logging.info('Setting up with TLS true')
        cm_client.configuration.verify_ssl = tls
        cm_client.configuration.ssl_ca_cert = ca_cert_path
        api_host = 'https://{host}'.format(host=cm_host)
        api_url = api_host + ':7183/api/' + cm_api_version
    else:
        logging.info("TLS is not enabled")
        api_host = 'http://{host}'.format(host=cm_host)
        api_url = api_host + ':7180/api/' + cm_api_version
        
    api_client = cm_client.ApiClient(api_url)
    return api_client


def log_properties_change(name, value):
    if "pass" in name:
        logger.info("Setting the property: {name} and the value: {value}".format(name=name, value='REDACTED'))
    else:
        logger.info("Setting the property: {name} and the value: {value}".format(name=name, value=value))

def handle_service_configs():
    configs = []
    log_properties_change(service_conf_name, service_value)
    configs.append(cm_client.ApiConfig(name=service_conf_name, value=service_value))
    if len(configs) > 0:
        msg = 'Updating parameter(s) for {service_type} reference {ref}'.format(service_type=service_type, ref=service_ref_name)
        try:
            print(msg)
            api_response = services_api_instance.update_service_config(cluster_name=cluster_name,
                                                                       service_name=service_ref_name,
                                                                       message=msg,
                                                                       body=cm_client.ApiConfigList(configs))
            pprint(api_response)
        except ApiException as e:
            print("Exception when calling ServicesResourceApi->update_config: %s\n" % e)
    else:
        print("No Service Configs to update")

if __name__ == '__main__':
    api_client = setup_api()
    
    #Set up API instances
    services_api_instance = cm_client.ServicesResourceApi(api_client)
    handle_service_configs()