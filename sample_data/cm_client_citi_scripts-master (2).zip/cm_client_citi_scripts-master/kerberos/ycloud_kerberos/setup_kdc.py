import os, sys, stat
import subprocess
import shutil
from os import listdir
from os.path import isfile, join
import pwd

kerberos_realm='TEST.COM'
kerberos_pw='cloudera'
ssh_user='root'
ssh_password='cloudera'
kdc_host='ccycloud-1.tkreutzer2.root.hwx.site'
non_kdc_hosts=['ccycloud-2.tkreutzer2.root.hwx.site',
               'ccycloud-3.tkreutzer2.root.hwx.site',
               'ccycloud-4.tkreutzer2.root.hwx.site',
               'ccycloud-5.tkreutzer2.root.hwx.site',
               'ccycloud-6.tkreutzer2.root.hwx.site',
               'ccycloud-7.tkreutzer2.root.hwx.site',
               'ccycloud-8.tkreutzer2.root.hwx.site',
               'ccycloud-9.tkreutzer2.root.hwx.site',
               'ccycloud-10.tkreutzer2.root.hwx.site',
               'ccycloud-11.tkreutzer2.root.hwx.site']
output_keytab_dir='/opt/cloudera/keytabs/'

principals=['HTTP','atlas','cruisecontrol','dn','flink','hbase','hdfs','hive','hue','impala',
            'kafka','knox','kudu','livy','mapred','nifi','nifiregistry','om','oozie','phoenix',
            'rangeradmin','rangerkms','rangerlookup','rangertagsync','rangerusersync','recon',
            'schemaregistry','scm','solr','spark','ssb','streamsmsgmgr','streamsrepmgr','yarn',
            'zeppelin','zookeeper']


"""
---------------------------------No configuration beyond this line -------------------
"""

class SubprocessCommandError(Exception):
    """An error code was returned while running the subprocess!"""

def process_sshpass_host(host, cmd):
    print("Processing on host {h}, command: {c}".format(h=host, c=cmd))
    get_command_result(construct_sshpass(host, cmd))
    print("Completed")
    
def process_sshpass_hosts(hosts, cmd):
    for host in hosts:
        print("Processing on host {h}, command: {c}".format(h=host, c=cmd))
        get_command_result(construct_sshpass(host, cmd))
        print("Completed")
        
def ssh_to_tgt_host(tgt_host, src_file, tgt_path):
    final_cmd = 'sshpass -p "{p}" scp {src_file} {u}@{tgt_host}:{tgt_path}'.format(p=ssh_password,
                                                                                   u=ssh_user,
                                                                                   src_file=src_file,
                                                                                   tgt_path=tgt_path,
                                                                                   tgt_host=tgt_host)
    get_command_result(final_cmd)
    
def construct_sshpass(host, cmd):
    #final_cmd = "sh exec_rem_cmd.sh {u} {p} {h} '{c}'".format(p=ssh_password, u=ssh_user,h=host,c=cmd)
    final_cmd = 'sshpass -p "{p}" ssh {u}@{h} -o StrictHostKeyChecking=no "{c}"'.format(p=ssh_password, u=ssh_user,h=host,c=cmd)
    return final_cmd

def create_krb5():
    krb_file = open("krb5.conf", "w")
    krb_file.write("[logging]\n")
    krb_file.write("default = FILE:/var/log/krb5libs.log\n")
    krb_file.write("kdc = FILE:/var/log/krb5kdc.log\n")
    krb_file.write("admin_server = FILE:/var/log/kadmind.log\n\n")
    krb_file.write("[libdefaults]\n")
    krb_file.write("dns_lookup_realm = false\n")
    krb_file.write("dns_lookup_kdc = false\n")
    krb_file.write("ticket_lifetime = 24h\n")
    krb_file.write("renew_lifetime = 7d\n")
    krb_file.write("forwardable = true\n")
    krb_file.write("default_realm = {realm}\n".format(realm=kerberos_realm))
    krb_file.write("default_ccache_name = /tmp/krb5cc_%{uid}\n\n")
    krb_file.write("[realms]\n")
    krb_file.write("{realm} = ".format(realm=kerberos_realm) + "{\n")
    krb_file.write(" kdc = {kdc}\n".format(kdc=kdc_host))
    krb_file.write(" admin_server = {kdc}\n".format(kdc=kdc_host))
    krb_file.write("}\n\n")
    krb_file.write("[domain_realm]\n")
    krb_file.write(" .{rl} = {r}\n".format(rl=kerberos_realm.lower(), r=kerberos_realm))
    krb_file.write(" {rl} = {r}\n".format(rl=kerberos_realm.lower(), r=kerberos_realm))
    krb_file.close()
    
def create_kdc_conf():
    conf = open("kdc.conf", "w")
    conf.write("[kdcdefaults]\n")
    conf.write("kdc_ports = 88\n")
    conf.write("kdc_tcp_ports = 88\n\n")
    conf.write("[realms]\n")
    conf.write("{r} = \n".format(r=kerberos_realm) + "{\n")
    conf.write("  acl_file = /var/kerberos/krb5kdc/kadm5.acl\n")
    conf.write("  dict_file = /usr/share/dict/words\n")
    conf.write("  admin_keytab = /var/kerberos/krb5kdc/kadm5.keytab\n")
    conf.write("  supported_enctypes = aes256-cts:normal aes128-cts:normal des3-hmac-sha1:normal arcfour-hmac:normal camellia256-cts:normal camellia128-cts:normal des-hmac-sha1:normal des-cbc-md5:normal des-cbc-crc:normal\n")
    conf.write("}\n")
    conf.close()

def create_kadm5_acl():
    kadm5 = open("kadm5.acl", "w")
    kadm5.write("*/admin@{r}     *".format(r=kerberos_realm))
    kadm5.close()
    
def create_retrieval_script():
    r = open("retrieve_credentials.sh", "w")
    r.write("#!/usr/bin/env bash\n")
    r.write("\n")
    r.write("set -x\n\n")
    r.write("# Explicitly add RHEL5/6 and SLES11 locations to path\n")
    r.write("export PATH=/usr/kerberos/sbin:/usr/lib/mit/sbin:/usr/sbin:$PATH\n\n")
    r.write("# CMF_REALM=${CMF_PRINCIPAL##*\@}\n")
    r.write("# Specify the path to a custom script (or executable) to retrieve a Kerberos keytab.\n")
    r.write("# The script should take two arguments: \n")
    r.write("# -     a destination file to write the keytab to, and \n")
    r.write("# -     the full principal name to retrieve the key for.\n\n\n")
    r.write("# Cloudera Manager will input a destination path\n")
    r.write("DEST=$1\n\n")
    r.write("# Cloudera Manager will input the principal name in the format: <service>/<fqdn>@REALM\n")
    r.write("PRINCIPAL=$2\n\n")
    r.write("service_name=`echo $PRINCIPAL | cut -d/ -f1`\n")
    r.write('host_name=`echo $PRINCIPAL | cut -d/ -f2 | cut -d"@" -f1`\n')
    r.write("which_keytab_to_use=${service_name}_${host_name}.keytab\n")
    r.write("cp /opt/cloudera/keytabs/${which_keytab_to_use} $DEST\n")
    r.write("echo PRINCIPAL = $PRINCIPAL DEST = $DEST which_keytab_to_use = $which_keytab_to_use\n\n")
    r.write("chmod 600 $DEST\n")
    r.close()


def create_principal_for_all_hosts(user, pw):
    get_command_result('kadmin.local -q "addprinc -pw {pw} {u}/{host}@{realm}"'.format(pw=pw,u=user,host=kdc_host,realm=kerberos_realm))
    for host in non_kdc_hosts:
        get_command_result('kadmin.local -q "addprinc -pw {pw} {u}/{host}@{realm}"'.format(pw=pw,u=user,host=host,realm=kerberos_realm))
        
def create_keytab_for_all_hosts(script, user, pw):
    get_command_result("sh {script} {u} {p} {h} {r} {d}".format(script=script, u=user,p=kerberos_pw, h=kdc_host, r=kerberos_realm, d=output_keytab_dir))
    for host in non_kdc_hosts:
        get_command_result("sh {script} {u} {p} {h} {r} {d}".format(script=script, u=user,p=kerberos_pw, h=host, r=kerberos_realm, d=output_keytab_dir))

def distribute_keytabs(user_name, group_name):
    allfiles = [f for f in listdir(output_keytab_dir) if isfile(join(output_keytab_dir, f))]
    for host in non_kdc_hosts:
        #Create the directory on the target host
        get_command_result('sshpass -p "{p}" ssh {u}@{tgt_host} -o StrictHostKeyChecking=no "mkdir -p {d}"'.format(p=ssh_password,
                                                                                                                    u=ssh_user,
                                                                                                                    tgt_host=host,
                                                                                                                    d=output_keytab_dir))
        #Change ownership of the target directory
        get_command_result('sshpass -p "{p}" ssh {u}@{tgt_host} -o StrictHostKeyChecking=no "chown {user_name}:{group_name} {d}"'.format(p=ssh_password,
                                                                                                                    u=ssh_user,
                                                                                                                    tgt_host=host,
                                                                                                                    d=output_keytab_dir,
                                                                                                                    user_name=user_name,
                                                                                                                    group_name=group_name))
        #Copy each file to the target host
        for f in allfiles:
            tgt_path = output_keytab_dir + f
            src_file = output_keytab_dir + f
            cm_uid=pwd.getpwnam(user_name).pw_uid
            cm_guid=pwd.getpwnam(group_name).pw_gid
            os.chown(tgt_path, cm_uid, cm_guid)
            if host in f:
                get_command_result('sshpass -p "{p}" scp {src_file} {u}@{tgt_host}:{tgt_path}'.format(p=ssh_password,
                                                                                                      u=ssh_user,
                                                                                                      src_file=src_file,
                                                                                                      tgt_path=tgt_path,
                                                                                                      tgt_host=host))
                get_command_result('sshpass -p "{p}" ssh {u}@{tgt_host} -o StrictHostKeyChecking=no "chown {user_name}:{group_name} {tgt_path}"'.format(p=ssh_password,
                                                                                                                                                        u=ssh_user,
                                                                                                                                                        src_file=src_file,
                                                                                                                                                        tgt_path=tgt_path,
                                                                                                                                                        tgt_host=host,
                                                                                                                                                        user_name=user_name,
                                                                                                                                                        group_name=group_name))

def chown_file_tgt_host(tgt_file, user_name, group_name):
    for host in non_kdc_hosts:
        get_command_result('sshpass -p "{p}" ssh {u}@{tgt_host} -o StrictHostKeyChecking=no "chown {user_name}:{group_name} {tgt_file}"'.format(p=ssh_password,
                                                                                                                                                u=ssh_user,
                                                                                                                                                tgt_host=host,
                                                                                                                                                user_name=user_name,
                                                                                                                                                group_name=group_name,
                                                                                                                                                tgt_file=tgt_file))
    
def get_command_result(command):
    """
    Used to execute terminal commands and get the return result
         :param command: command to be executed
    :return:
    """
    print("Command: " + command)
    output_stdout, output_error = "None1", "None2"
    try:
        popen = subprocess.Popen(command, stdout=subprocess.PIPE, stderr=subprocess.PIPE, shell=True, bufsize=4096)
        output_stdout, output_error = popen.communicate()
        exit_code = popen.wait()
    except Exception as e:
        print("exec command error: {}".format(e))
    finally:
        return output_stdout.decode(), output_error.decode()


if __name__ == '__main__':
    #Setting up KDC on the main host followed by Kerberos dependencies on other hosts
    process_sshpass_host(kdc_host, "yum install -y krb5-server krb5-libs krb5-workstation")
    process_sshpass_hosts(non_kdc_hosts, 'yum install -y krb5-libs krb5-workstation')
    
    
    #Create required kerberos files
    create_krb5()
    create_kdc_conf()
    create_kadm5_acl()
    
    #distribute the files to the proper location
    shutil.copy('krb5.conf', '/etc/krb5.conf')
    for host in non_kdc_hosts:
        sss_to_tgt_host(host, 'krb5.conf', '/etc/krb5.conf')
    shutil.copy('kdc.conf', '/var/kerberos/krb5kdc/kdc.conf')
    shutil.copy('kadm5.acl', '/var/kerberos/krb5kdc/kadm5.acl')
    
    
    #-P password
    # specifies the master database password. This option is not recommended.
    # however, for building example clusters it will be OK otherwise use pexpect
    get_command_result("kdb5_util create -s -P {pw}".format(pw=kerberos_pw))
    
    
    #Start the KDC. Start the KDC server and the KDC admin server.
    get_command_result("systemctl start krb5kdc")
    get_command_result("systemctl start kadmin")
    
    #Set up the KDC server to auto-start on boot:
    get_command_result("systemctl enable krb5kdc")
    get_command_result("systemctl enable kadmin")
    
    
    #Create a KDC admin by creating an admin principal
    get_command_result('kadmin.local -q "addprinc -pw {pw} admin/admin"'.format(pw=kerberos_pw))
    
    #for testing I am going to create a user for each host regardless of the service being deployed or not. 
    
    
    for principal in principals:
        create_principal_for_all_hosts(principal, kerberos_pw)
    
    
    os.chmod("/root/create_keytab.sh", stat.S_IEXEC)
    os.chmod("/root/create_keytab_with_http.sh", stat.S_IEXEC)
    
    
    get_command_result("rm -rf {output_keytab_dir}*".format(output_keytab_dir=output_keytab_dir))
    for principal in principals:
        create_keytab_for_all_hosts('create_keytab.sh', principal, kerberos_pw)
    
    
    #Create and distribute the retrieval script
    create_retrieval_script()
    
    cm_uid=pwd.getpwnam('cloudera-scm').pw_uid
    cm_guid=pwd.getpwnam('cloudera-scm').pw_gid
    os.chown('/root/retrieve_credentials.sh', cm_uid, cm_guid)
    os.chmod('/root/retrieve_credentials.sh', stat.S_IRWXU)
    shutil.copy('/root/retrieve_credentials.sh', '/opt/cloudera/retrieve_credentials.sh')
    os.chown('/opt/cloudera/retrieve_credentials.sh', cm_uid, cm_guid)
    os.chown(output_keytab_dir, cm_uid, cm_guid)
    get_command_result('chown cloudera-scm:cloudera-scm {output_keytab_dir}*'.format(output_keytab_dir=output_keytab_dir))
    
    """for host in non_kdc_hosts:
        ssh_to_tgt_host(host, 'retrieve_credentials.sh', '/opt/cloudera/retrieve_credentials.sh')
    chown_file_tgt_host('/opt/cloudera/retrieve_credentials.sh', 'cloudera-scm', 'cloudera-scm')
    
    distribute_keytabs('cloudera-scm','cloudera-scm')"""
