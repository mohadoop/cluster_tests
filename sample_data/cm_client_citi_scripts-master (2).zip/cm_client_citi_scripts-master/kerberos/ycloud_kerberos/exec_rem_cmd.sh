#!/bin/bash

# sh exec_rem_cmd.sh root cloudera ccycloud-2.tkreutzer.root.hwx.site 'ls -ltr /root/'

ssh_user=${1}
ssh_password=${2}
host=${3}
cmd=${4}

sshpass -p "${ssh_password}" ssh ${ssh_user}@${host} -o StrictHostKeyChecking=no "${cmd}"
