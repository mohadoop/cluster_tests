#!/bin/bash

user=${1}
pass=${2}
host=${3}
realm=${4}
output_keytab_dir=${5}

mkdir -p ${output_keytab_dir}
principal="${user}/${host}@${realm}"
filetocreate="${output_keytab_dir}${user}_${host}.keytab"


# Now adding all the user entries. 
if [ "$user" != "HTTP" ]; then
    printf "%b" "addent -password -p $principal -k 1 -e aes256-cts-hmac-sha1-96\n$pass\nwrite_kt $filetocreate" | ktutil
    printf "%b" "addent -password -p $principal -k 1 -e aes128-cts-hmac-sha1-96\n$pass\nwrite_kt $filetocreate" | ktutil
    printf "%b" "addent -password -p $principal -k 1 -e arcfour-hmac\n$pass\nwrite_kt $filetocreate" | ktutil
fi
exit 0