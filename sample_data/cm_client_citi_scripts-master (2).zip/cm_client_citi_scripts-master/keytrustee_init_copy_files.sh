#!/bin/bash

scp_user=root
tgt_host=ccycloud-11.tkreutzer2.root.hwx.site


#DO NOT CONFIGURE BEYOND THIS LINE
keytrustee_path="/var/lib/keytrustee/.keytrustee/"

ktadmin init
if [ $? -eq 0 ]; then
    echo "Successfully executed ktadmin init on the Active Host"
else
    echo "ERROR: Failed to execute ktadmin init on the Active Host!"
    exit 1
fi


echo "Moving the contents of ${keytrustee_path} to the target host ${tgt_host} with the user ${scp_user}"

scp -r ${keytrustee_path}* root@${tgt_host}:${keytrustee_path}

if [ $? -eq 0 ]; then
    echo "Successfully copied the ${keytrustee_path} to the target host"
    exit 0
else
    echo "ERROR: The process to copy the data to the target host has failed!"
    exit 1
fi


ssh ${scp_user}@${tgt_host} -o StrictHostKeyChecking=no "chown -R keytrustee:keytrustee ${keytrustee_path}"
if [ $? -eq 0 ]; then
    echo "Successfully executed chown for keytrustee ${keytrustee_path} on target host ${tgt_host}"
else
    echo "ERROR: Failed to check keytrustee directory on target host!"
    exit 1
fi