############################################################################################################################################
# File Name: update_role_config.py
# Author: Thomas Kreutzer
# Date created: Aug 9, 2021
# Date last modified: Aug 9, 2021
# Python Version: 2.7.5
# CM Python API Version: 41
# Description: Following script is to be used to update a single configuration per call, generally to be used for passwords or other sensitive
#               parameters. This call is expected to be called and pass in the passwords to this script from Ansible. 
# Change Log
# Change Number | Date MM-DD-YYYY  | Changed By        | Change Description
# Initial       | 08-09-2021       | Thomas Kreutzer   | Initial code draft 
# 
#
# Values likely required to be updated with this script.
#
# FOR "serviceType": "ATLAS", "refName": "atlas", "roleConfigGroups": [{"refName": "atlas-ATLAS_SERVER-BASE"
# atlas_admin_password
# 
# FOR "serviceType": "OOZIE", "refName": "oozie", "roleConfigGroups": [{"refName": "oozie-OOZIE_SERVER-BASE"
# oozie_database_password
#
############################################################################################################################################

import socket
import sys
import cm_client
from cm_client.rest import ApiException
from collections import namedtuple
from pprint import pprint
from logging import error
import logging

logger = logging.getLogger('update_role_config')
logger.setLevel(logging.DEBUG)


"""
Cloudera Manager configurations
"""
cm_user = 'admin'
cm_pass = 'admin'
cm_api_version = 'v41'
tls=True
ca_cert_path = '/opt/cloudera/security/pki/rootCA.pem'
cluster_name = 'CDP_cluster_0701_3'

#configurations to be set with Ansible
service_ref_name="{{ service_ref_name }}"
rcg_ref_name="{{ rcg_ref_name }}"
rcg_conf_name="{{ rcg_conf_name }}"
rcg_value="{{ rcg_value }}"

#For testing, remove for production
service_ref_name="atlas"
rcg_ref_name="atlas-ATLAS_SERVER-BASE"
rcg_conf_name="atlas_admin_password"
rcg_value="Cloudera123"


"""
 No Configuration Required beyond this line
------------------------------------------------------------------------------------------
"""
role_api_instance=''

def setup_api():
    """
    Helper to set up the Cloudera Manager API
    This assumes that you are executing this script on the 
    Cloudera Manager host
    :return: api_client
    """
    cm_host = socket.gethostname()
    cm_client.configuration.username = cm_user
    cm_client.configuration.password = cm_pass
    if tls:
        logging.info('Setting up with TLS true')
        cm_client.configuration.verify_ssl = tls
        cm_client.configuration.ssl_ca_cert = ca_cert_path
        api_host = 'https://{host}'.format(host=cm_host)
        api_url = api_host + ':7183/api/' + cm_api_version
    else:
        logging.info("TLS is not enabled")
        api_host = 'http://{host}'.format(host=cm_host)
        api_url = api_host + ':7180/api/' + cm_api_version
        
    api_client = cm_client.ApiClient(api_url)
    return api_client


def log_properties_change(name, value):
    if "pass" in name:
        logger.info("Setting the property: {name} and the value: {value}".format(name=name, value='REDACTED'))
    else:
        logger.info("Setting the property: {name} and the value: {value}".format(name=name, value=value))

def handle_role_configs():
    configs = []
    msg = 'Updating parameter(s) for {rcn} and role config group {rcg}'.format(rcn=rcg_conf_name, rcg=rcg_value)
    log_properties_change(rcg_conf_name, rcg_value)
    configs.append(cm_client.ApiConfig(name=rcg_conf_name, value=rcg_value))
    try:
        print(msg)
        body=cm_client.ApiConfigList(configs)
        print(body)
        api_response = role_api_instance.update_config(cluster_name=cluster_name,
                                                          role_config_group_name=rcg_ref_name,
                                                          service_name=service_ref_name,
                                                          message=msg,
                                                          body=body)
        pprint(api_response)
    except ApiException as e:
        print("Exception when calling RoleConfigGroupsResourceApi->update_config: %s\n" % e)

if __name__ == '__main__':
    api_client = setup_api()
    
    #Set up API instances
    role_api_instance = cm_client.RoleConfigGroupsResourceApi(api_client)
    handle_role_configs()