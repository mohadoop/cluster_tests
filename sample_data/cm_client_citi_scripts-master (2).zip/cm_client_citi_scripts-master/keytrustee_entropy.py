import platform
import sys
import shlex
from subprocess import Popen, PIPE

entropy_comand="sudo cat /proc/sys/kernel/random/entropy_avail"
entropy_threshold=500

class SubprocessCommandError(Exception):
    """An error code was returned while running the subprocess!"""

def get_linux_distribution():
  try:
    return platform.linux_distribution()
  except:
    return "N/A"

def get_os_version_number(distro):
    version = distro[1].split('.')[0]
    print("Linux OS Version: {v}".format(v=version))
    return int(version)

def exec_command(cmd):
    process = Popen(shlex.split(cmd), stdout=PIPE)
    out, err = process.communicate()
    exit_code = process.wait()
    print("Exit code: {exit_code}".format(exit_code=exit_code))
    if exit_code != 0:
        raise SubprocessCommandError
    return out

def process_linux6():
    print("This has not been tested")
    exec_command()
    first_command = "echo 'EXTRAOPTIONS=" + '"-r /dev/urandom" ' + ">> /etc/sysconfig/rngd"
    exec_command(first_command)
    exec_command('service rngd start')
    exec_command('chkconfig rngd on')

def process_linux7():
    exec_command('sudo yum install rng-tools -y')
    #Check if the file rngd.service exists in /etc/systemd/system/
    ls1 = exec_command('sudo ls -ltr /etc/systemd/system/')
    print(ls1)
    if 'rngd.service' not in ls1:
        print('Did not find rngd.service in /etc/systemd/system/ -- Copying')
        exec_command('sudo cp /usr/lib/systemd/system/rngd.service /etc/systemd/system/')
        exec_command("sudo sed -i -e 's/ExecStart=\/sbin\/rngd -f/ExecStart=\/sbin\/rngd -f -r \/dev\/urandom/' /etc/systemd/system/rngd.service")
        exec_command('sudo systemctl daemon-reload')
        exec_command('sudo systemctl start rngd')
        result=exec_command('sudo systemctl status rngd')
        if 'Loaded: loaded' in result and 'Active: active' in result:
            print("Successfully loaded and active")
        else:
            exec_command('sudo systemctl enable rngd')


def install_rng_tools():
    distro = get_linux_distribution()
    version_number=get_os_version_number(distro)
    if version_number == 7:
        process_linux7()
    else:
        process_linux6()

if __name__ == '__main__':
    entropy=exec_command(entropy_comand)
    if int(entropy) < entropy_threshold:
        print("Installing rng")
        install_rng_tools()
    else:
        print("Entropy is {c} which is above the threshold {t}, no action will be taken.".format(c=entropy, t=entropy_threshold))
