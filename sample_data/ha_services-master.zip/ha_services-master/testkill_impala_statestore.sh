 #!/bin/bash
# sh testkill.sh 6 30
re='^[0-9]+$'
echo "Running test kill script"
echo "Script terminates statestore process"
echo "Process will be killed $1 time in every $2 seconds"
echo "-------------------------------------------------------------------------------"
for counter in $(seq 1 $1)
do
        echo "Starting iteration $counter: $(date)"
        pid=$(ps -Af | grep -i "statestored" | grep -v "grep" | awk '{print $2}')
        if ! [[ $pid =~ $re ]] ; then
            echo "Warning!: could not find any active Impala statestore on this iteration, skipping!"
        else
            echo "Found the pid ${pid} related to Impala statestore, killing process"
            kill -9 ${pid}
            echo "Process killed"
        fi
        echo "-------------------------------------------------------------------------------"
        sleep $2
done