service_monitor
-----------------------------

### Goal
Provide some capability to move a service is a host is in bad health, the number of restarts in a certain time frame is exceeded or if the service shows bad and restarts have not been attempted.

### Changes
The original version was created for cm_api and this has been rewritten to work with cm_client. The old version of the script is stored as service_mover_cm_api.py

### Configuration
There are several files that require configuration to execute.

1. application.conf
2. service_mover.py
3. logging.conf
4. The file for the service you plan to execute (IMCSHA, IMPSSHA, JHSHA, SHSHA)


Each service should be deployed to it's own folder, a copy of the core code can be delivered to that directory. 
Once it has been deployed, start with configurations for application.conf. 

#### Configuring application.conf

**[clouderaManager]**
Configure all the details for your cloudera manager instance including the URL, API version, cluster name and if TLS is configured. 

In addition, if you have a method of encrypting the password for the admin as to not store it in plain text, you can configure it for Command and then provide the proper command. 
This utility does not provide encryption/decryption

**[alertingService]**
Allows you to configure alerts and failures to be routed to an email address. 

**[FailoverServers]**
This section is where you configure the original installation of the service followed by the new locations it could be migrated to. 
It is assumed that you have hardware available so that if a failure occurs the roles can be moved. 

**[FailoverThresholds]**
Some of the failover threshold work in conjunction with each other for this release. 

For example: The client the original scripts had been created for experienced a situation where a role went bad but did not completely crash. 
In this case, since there were 0 restart attempts, the service was never migrated. With the new version the **monitoringTimeThreshold** is used with **BadRoleCheckCountThreshold** 
to correct that issue. **monitoringTimeThreshold** is in minutes so if you set this 1 the program checks for a problem every minute. With the combination of the two, if **BadRoleCheckCountThreshold** 
is set to 5 it will be in a bad state for five minutes before it attempts to move the role to another host. 

**[FailoverScript]**
Under this section **loggingConfigFile** needs to be configured for where your logging configuration is.
The configuration **PidFileName** is important to configure correctly and must match what you configured in the script to start/stop the program
Most of the other configs could likely be left default.


**[ApiVariables]**
These all need to be configured to match what is appropriate for the service and role you plan to monitor.



#### Configuring service_mover.py
The constant **ConfigFilePath** is the only update required to point to your application.conf.
This could likely be made into a relative path instead of fully qualified, but I have not tested.

#### Configuring logging.conf
Obviously the debug log level you desire is what really needs to be updated, aside from that there is **args* and this points to where the log should write and is required to be updated. 

#### Configuring (IMCSHA, IMPSSHA, JHSHA, SHSHA)
Each of these are prepared for their respective services/roles. 
First update **prog** and make sure it matches with the **PidFileName** from above
Second update **exec** to point to the path where service_mover.py has been deployed.


### Starting the application
Finally if you have everything configured correctly, you can start/stop the application

**Start Command**
```bash
IMCSHA start
```

**Stop Command**
```bash
IMCSHA stop
```