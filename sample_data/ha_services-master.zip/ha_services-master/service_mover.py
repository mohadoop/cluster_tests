############################################################################################################################################
# File Name: service_mover.py
# Author: Thomas Kreutzer
# Date created: May 18, 2021
# Date last modified: May 18, 2021
# Python Version: 2.7.5
# CM Python API Version: 14
# Description: Following script is meant to replicate HA functionality for Impala State Store and automatically move it to a new host 
#              and restart Impala. This script is based off the original scripts created by Ashish Tyagi. This script will also add
#              restarting the entire Impala service once a move is done as is required to make it effective.
# Change Log
# Change Number | Date MM-DD-YYYY  | Changed By        | Change Description
# Initial       | 04-13-2017       | Ashish Tyagi      | Initial code draft 
# 1             | 04-17-2017       | Ashish Tyagi      | Added logging and email alerts 
# 2             | 05-01-2017       | Ashish Tyagi      | Added secure password reading
# 3             | 05-18-2021       | Thomas Kreutzer   | Initial code draft for impala state store
# 4             | 07-15-2021       | Thomas Kreutzer   | Fixed issue with TLS
# 5             | 07-16-2021       | Thomas Kreutzer   | Fixed issue with protocol duplication in requests calls
#
# Investigate this page https://github.com/sihuamanu/edge2ai_demo/blob/master/create_cluster.py
############################################################################################################################################

import os
import logging
import subprocess
import smtplib
import logging.config
import ConfigParser
#import time, datetime
from datetime import datetime
import time
import cm_client
from cm_client.rest import ApiException
from email.MIMEMultipart import MIMEMultipart
from email.MIMEText import MIMEText
from email.MIMEImage import MIMEImage
from pprint import pprint
import requests #Using requests where cm_client fails to function properly we will use straight curl
from requests.auth import HTTPBasicAuth
import json


class ServiceStopTimeoutError(Exception):
    """The service was attempted to be stopped, but exceeded the timeout configured."""
class ServiceRestartTimeoutError(Exception):
    """The service was attempted to be restarted, but exceeded the timeout configured."""
class RoleStopTimeoutError(Exception):
    """The role was attempted to be stopped, but exceeded the timeout configured."""
class RoleRestartTimeoutError(Exception):
    """The role was attempted to be restarted, but exceeded the timeout configured."""
    
# Define constants 
ConfigFilePath = "/opt/cgfiles/common/bin/impss_ha/application.conf"
rolesEndpoint="/clusters/{clusterName}/services/{serviceName}/roles"
roleNameEndpoint="/clusters/{clusterName}/services/{serviceName}/roles/{roleName}"

# Read application.conf file
config = ConfigParser.SafeConfigParser()
config.read(ConfigFilePath)

# Populate required variables from configuration file
clouderaManagerHost = config.get("clouderaManager", "clouderaManagerHost")
clouderaManagerPort = config.getint("clouderaManager", "clouderaManagerPort")
clouderaManagerApiVersion = config.getint("clouderaManager", "clouderaManagerApiVersion")
clouderaManagerHTTPS = config.getboolean("clouderaManager", "clouderaManagerHTTPS")
clouderaManagerPEM = config.get("clouderaManager","clouderaManagerPEM")
clouderaManagerUserName = config.get("clouderaManager", "clouderaManagerUserName")
clusterDisplayName = config.get("clouderaManager", "clusterDisplayName")
sendAlertEmail = config.getboolean("alertingService", "sendAlertEmail")
sendSuccessEmail = config.getboolean("alertingService", "sendSuccessEmail")
sendFailureEmail = config.getboolean("alertingService", "sendFailureEmail")
alertEmailIcon = config.get("alertingService", "alertEmailIcon")
alertEmailUseTLS = config.getboolean("alertingService", "alertEmailUseTLS")
alertEmailFromAddress = config.get("alertingService", "alertEmailFromAddress")
alertEmailToAddress = config.get("alertingService", "alertEmailToAddress")
SMTPServerAddress = config.get("alertingService", "SMTPServerAddress")
SMTPServerPort = config.getint("alertingService", "SMTPServerPort")
ServicePrimaryHost = config.get("FailoverServers", "ServicePrimaryHost")
ServiceFailoverHosts = config.get("FailoverServers", "ServiceFailoverHosts").split(',')
GoodHostTimeThreshold = config.getint("FailoverThresholds", "GoodHostTimeThreshold")
BadHostTimeThreshold = config.getint("FailoverThresholds", "BadHostTimeThreshold")
GoodHostRestartThreshold = config.getint("FailoverThresholds", "GoodHostRestartThreshold")
BadHostRestartThreshold = config.getint("FailoverThresholds", "BadHostRestartThreshold")
BadRoleCheckCountThreshold = config.getint("FailoverThresholds", "BadRoleCheckCountThreshold")
monitoringTimeThreshold = config.getint("FailoverScript", "monitoringTimeThreshold")
commandTimeOut = config.getint("FailoverScript", "commandTimeOut")
maintenanceModeCheck = config.getboolean("FailoverScript", "maintenanceModeCheck")
loggingConfigFile = config.get("FailoverScript", "loggingConfigFile")
loggerName = config.get("FailoverScript", "loggerName")
moveServiceSuccessTimeThreshold = config.getint("FailoverScript", "moveServiceSuccessTimeThreshold")
PidFileName = config.get("FailoverScript","PidFileName")
# create a process ID file in /var/run/impssha
ServiceType = config.get("ApiVariables","ServiceType")
RoleType = config.get("ApiVariables","RoleType")
HostHealthCheckName = config.get("ApiVariables","HostHealthCheckName")
ServiceTypeName = config.get("ApiVariables","ServiceTypeName")
RoleTypeName = config.get("ApiVariables","RoleTypeName")


# Get secure passwords for login 
clouderaManagerPasswordMode = config.get("clouderaManager", "clouderaManagerPasswordMode")
clouderaManagerPassword = "admin"
if clouderaManagerPasswordMode == "Command":
    clouderaManagerPasswordCommand = config.get("clouderaManager", "clouderaManagerPassword").split(' ')
    clouderaManagerPassword = subprocess.Popen(clouderaManagerPasswordCommand, stdout=subprocess.PIPE).stdout.read().strip()
elif clouderaManagerPasswordMode == "Plain":
    clouderaManagerPassword = config.get("clouderaManager", "clouderaManagerPassword")
SMTPServerAuthentication = config.getboolean("alertingService", "SMTPServerAuthentication")
if SMTPServerAuthentication:
    SMTPServerPasswordMode = config.get("alertingService", "SMTPServerPasswordMode")
    SMTPServerPassword = "admin"
    if SMTPServerPasswordMode == "Command":
        SMTPServerPasswordCommand = config.get("alertingService", "SMTPServerPassword").split(' ')
        SMTPServerPassword = subprocess.Popen(SMTPServerPasswordCommand, stdout=subprocess.PIPE).stdout.read().strip()
    elif SMTPServerPasswordMode == "Plain":
        SMTPServerPassword = config.get("alertingService", "SMTPServerPassword")

# Enable logging and get logger handle 
logging.config.fileConfig(loggingConfigFile)
logger = logging.getLogger(loggerName)


# Define global variables
api = None
cluster = None
clusterService = None
currentServiceRole = None
currentServiceRoleHostHealth = False
currentRoleFailCheckCount = 0

def dump(obj):
  for attr in dir(obj):
    print("obj.%s = %r" % (attr, getattr(obj, attr)))

#-------------------------------------------------------------------------------------------------------------------
def wait(cmd, timeout=None):
    SYNCHRONOUS_COMMAND_ID = -1
    if cmd.id == SYNCHRONOUS_COMMAND_ID:
        return cmd

    SLEEP_SECS = 5
    if timeout is None:
        deadline = None
    else:
        deadline = time.time() + timeout

    try:
        cmd_api_instance = cm_client.CommandsResourceApi(api_client)
        while True:
            cmd = cmd_api_instance.read_command(long(cmd.id))
            print(datetime.strftime(datetime.now(), '%c'))
            logger.debug(cmd)
            if not cmd.active:
                return cmd

            if deadline is not None:
                now = time.time()
                if deadline < now:
                    return cmd
                else:
                    time.sleep(min(SLEEP_SECS, deadline - now))
            else:
                time.sleep(SLEEP_SECS)
    except ApiException as e:
        print("Exception when calling ClouderaManagerResourceApi->import_cluster_template: %s\n" % e)

#-------------------------------------------------------------------------------------------------------------------
# Sending email when Service is moved
def SendMail(**kwargs):
    logger.info("Sending " +str(RoleTypeName)+ " " + kwargs['Mode'] +" email")
    try:
        msg = MIMEMultipart('related')
        msg['From'] = alertEmailFromAddress
        msg['Bcc'] = alertEmailToAddress
        msg['Subject'] = "Cluster: " + str(cluster.display_name) +" - " +str(RoleTypeName)+" Server Move (HA)"
        
        if kwargs['Mode'] == 'Move':
            msgText = MIMEText(
                               '<p>' + \
                               'Moving '+ str(RoleTypeName) +' Server to a New Host: <br>' + \
                               '<b>Move Reason:</b><br>' + \
                               kwargs['moveReason'] + '<br>' +\
                               '<b>Cluster Name: '+ str(cluster.display_name)  +'</b><br>' + \
                               '<b>Current ' + str(RoleTypeName) +' Server Host: </b>' + kwargs['currentHost'] + '<br>' + \
                               '<b>New ' + str(RoleTypeName) +' Server Host: </b>' + kwargs['newHost'] + '<br><br>' + \
                               '</br>Possible "Config change: Restart required" alerts can be seen on different services.( <img src="cid:image1"> ) <br>' + \
                               'These alerts seen on CM UI have no impact on the cluster and can be safely ignored.<br>' + \
                               'If anyone happens to have done a purposeful configuration change and saved them, ' + \
                               'then a restart on that particular service or instance would be needed.<br><br>' + \
                               'Thanks,<br>Operations' + \
                               '</p>', \
                               'html')
            msg.attach(msgText)
            img = open(alertEmailIcon, 'rb')
            msgImage = MIMEImage(img.read())
            img.close()
            msgImage.add_header('Content-ID', '<image1>')
            msg.attach(msgImage)
            
        elif kwargs['Mode'] == 'Success':
            msg.attach(MIMEText("Succeeded in moving "+str(RoleTypeName)+" Server to new host", 'plain'))
        elif kwargs['Mode'] == 'Failure':
            msgText = MIMEText('<p>' + \
                               'Failed to move '+str(RoleTypeName)+' Server to new host <br><br>' + \
                               '<b>Failure Reason: </b>' + \
                               kwargs['failureReason'] + '<br>' + \
                               '<b>Error message: </b>' + \
                               kwargs['failureErrorMessage'] + '<br>' + \
                               '</p>','html')
            msg.attach(msgText)
                
        server = smtplib.SMTP(SMTPServerAddress, SMTPServerPort)
        if alertEmailUseTLS:
            server.starttls()
        if SMTPServerAuthentication:
            server.login(alertEmailFromAddress, SMTPServerPassword)
        text = msg.as_string()
        server.sendmail(alertEmailFromAddress, alertEmailToAddress, text)
        server.quit()
    except Exception as err:
        logger.debug("Error sending email: " + str(err)) 

#-------------------------------------------------------------------------------------------------------------------
def getServiceInfo():
    global clusterService
    services = services_resource_api_instance.read_services(clusterDisplayName, view='FULL')
    for service in services.items:
        if service.type == ServiceType:
            clusterService = service
            break

#-------------------------------------------------------------------------------------------------------------------
def getRoleInfo():
    global currentServiceRole
    # Get current Role
    roles = roles_resource_api_instance.read_roles(clusterDisplayName, clusterService.name)
    for role in roles.items:
        if role.type == RoleType:
            currentServiceRole = role
            break

#-------------------------------------------------------------------------------------------------------------------
# Refreshes state for global variables representing cluster, service and role
def refreshGlobals():
    logger.debug("Refreshing handles")
    global cluster
    global clusterService
    global currentServiceRole
    try:
        # Get required cluster
        cluster = cluster_resource_api_instance.read_cluster(clusterDisplayName)
        # Get service
        logger.debug("Getting "+str(ServiceTypeName)+" service handle")
        services = services_resource_api_instance.read_services(clusterDisplayName, view='FULL')
        for service in services.items:
            #print service.display_name, "-", service.type
            logger.debug("Service Display Name: " + service.display_name + " - Service Type: " + service.type)
            if service.type == ServiceType:
                logger.debug("Found service type "+ ServiceType)
                clusterService = service
                break
        # Get current Role
        roles = roles_resource_api_instance.read_roles(clusterDisplayName, clusterService.name)
        for role in roles.items:
            if role.type == RoleType:
                logger.debug("Found Role Type: " + role.type)
                currentServiceRole = role
                break
    except ApiException as err:
        logger.error("Failed to refresh handles > " + str(err))

#-------------------------------------------------------------------------------------------------------------------
def checkRestartAttempts(hostTimeThreshold, hostRestartThreshold, hostHealth):
    logger.debug("Current "+str(RoleTypeName)+" host health is "+hostHealth+" checking last " + \
             str(hostTimeThreshold) + \
             " minute(s) of data to check if number of restart attempts are " + \
             str(hostRestartThreshold) + " or more")
    
    from_time = datetime.fromtimestamp(time.time() - (60 * hostTimeThreshold)) 
    to_time = datetime.fromtimestamp(time.time())
    query = "SELECT sum(integral(unexpected_exits_rate)) WHERE roleType = " +  RoleType + " AND clusterDisplayName = '" + clusterDisplayName + "'"
    logger.debug("query is " + query)
    timeSeriesResult = time_series_resource_api_instance.query_time_series(query=query, _from=from_time, to=to_time)
    numberOfRestarts = 0.0
    for timeSeries in timeSeriesResult.items[0].time_series:
        for point in timeSeries.data:
            numberOfRestarts = point.value / 60
            logger.debug("numberOfRestarts= " + str(numberOfRestarts))
    if numberOfRestarts < hostRestartThreshold:
        logger.debug("Current value under threshold skipping this iteration: " + str(numberOfRestarts))
        return True #Keep checking
    else:
        logger.info("Current value above threshold initiating "+str(RoleTypeName)+" move to new host")
        moveService()
        return False #Do not check next step as we just moved the service

#-------------------------------------------------------------------------------------------------------------------
def checkRoleBadHealthAttempts():
    global currentRoleFailCheckCount
    logger.debug("Current "+str(RoleTypeName)+" role health is BAD count " + \
                 str(currentRoleFailCheckCount) + \
                 " times for the threshold " + str(BadRoleCheckCountThreshold) + \
                 " checking every " +str(monitoringTimeThreshold)+ " minute(s)." )
    
    from_time = datetime.fromtimestamp(time.time() - (60 * BadHostTimeThreshold))
    to_time = datetime.fromtimestamp(time.time())
    query = "SELECT health_bad_rate WHERE roleType = " +  RoleType + " AND clusterDisplayName = '" + clusterDisplayName + "'"
    logger.debug("query is " + query)
    logger.debug("It checks between " + str(from_time) + " and " + str(to_time))
    timeSeriesResult = time_series_resource_api_instance.query_time_series(query=query, _from=from_time, to=to_time)
    for timeSeries in timeSeriesResult.items[0].time_series:
        #logger.debug("timeSeries: " + str(timeSeries))
        for point in timeSeries.data:
            finalVal = 0
            #logger.debug("point.value: " + str(point.value))
            if point.value > finalVal:
                finalVal = point.value
    if finalVal > 0:
        currentRoleFailCheckCount +=1
    if finalVal == 0: #If it is 0, we should reset as we do not want to keep the count if self-corrects
        currentRoleFailCheckCount=0
    
    #finally check if we exceed bad count
    if currentRoleFailCheckCount < BadRoleCheckCountThreshold:
        logger.debug("Current value "+str(currentRoleFailCheckCount)+" under threshold "+str(BadRoleCheckCountThreshold)+" skipping this iteration")
        return True #Keep checking
    else:
        logger.info("Current value above threshold initiating "+str(RoleTypeName)+" move to new host")
        moveService()
        return False #Do not check next step as we just moved the service

#-------------------------------------------------------------------------------------------------------------------
def monitorService():
    global currentServiceRoleHostHealth
    global currentServiceRoleHealth
    global currentRoleFailCheckCount
    logger.info("Starting monitoring")
    while True:
        logger.info("Starting next monitoring iteration")
        try:
            # Get latest state for cluster, service and role
            refreshGlobals()
            logger.debug("Getting running command list for cluster and "+str(RoleTypeName)+" service")
            clusterCommands = cluster_resource_api_instance.list_active_commands(clusterDisplayName)
            serviceCommands = mgmt_service_resource_api_instance.list_active_commands()
            
            # Check Service host's health
            logger.debug("Checking current "+str(RoleTypeName)+" host health")
            currentServiceRoleHostHealth = False
            for health_check in currentServiceRole.health_checks:
                if health_check.name == HostHealthCheckName and health_check.summary == 'GOOD':
                    currentServiceRoleHostHealth = True
                    break
            logger.debug("Current "+str(RoleTypeName)+" server 'host' health: " + str(currentServiceRoleHostHealth and "Good" or "Bad")
                         + " - the service itself may still be down regardless of host health.")
            
            # Check if Service is up and running normally
            logger.debug("Checking current "+str(RoleTypeName)+" status")
            currentServiceRoleHealth = False
            
            if currentServiceRole.role_state == "STARTED" and currentServiceRole.health_summary == "GOOD":
                currentServiceRoleHealth = True
            
            #Run a series of checks, if preceding is flagged false, stop checking further.
            keepChecking = True
            # Check if cluster is in maintenance mode or stopped
            logger.debug("Checking if cluster or "+ str(RoleTypeName) +" is in maintenance mode or there are any commands running on them")
            if maintenanceModeCheck and cluster.maintenance_mode:
                keepChecking=False
                logger.debug("Cluster in maintenance mode skipping further checks")
            
            # Check if cluster is stopped or is stopping
            if keepChecking:
                if cluster.entity_status in ["STOPPING", "STOPPED"]:
                    keepChecking = False
                    logger.debug("Cluster in currently stopped or is stopping, skipping further checks")
            
            # Check if cluster is running any command right now
            if keepChecking:
                if len(clusterCommands.items) != 0 and clusterCommands.items[0].name in ["Start","Restart","Stop"]:
                    keepChecking = False
                    logger.debug("There are running commands on cluster skipping further checks")
            
            # Check if service is in maintenance mode or stopped
            if keepChecking:
                if maintenanceModeCheck and clusterService.maintenance_mode:
                    keepChecking = False
                    logger.debug(str(RoleTypeName) +" service is in maintenance mode skipping further checks")
            
            # Check if service is stopped or is stopping
            if keepChecking:
                if clusterService.service_state in ["STOPPING", "STOPPED"]:
                    keepChecking = True
                    logger.debug(str(RoleTypeName) +" service is currently stopped skipping further checks")
            
            # Check if cluster is running any command right now
            if keepChecking:
                if len(serviceCommands.items) != 0 and serviceCommands.items[0].name in ["Start","Restart","Stop"]:
                    keepChecking = True
                    logger.debug("There are running commands on "+str(RoleTypeName)+" service skipping further checks")
            
            # Check last Good/Bad HostTimeThreshold min of time series data
            # to see number or restart attempts 
            # if more than Good/Bad HostRestartThreshold move the Service.
            if keepChecking:
                if currentServiceRoleHostHealth: #If host health is good
                    keepChecking = checkRestartAttempts(GoodHostTimeThreshold, GoodHostRestartThreshold, "GOOD")
                else: #If host health is bad
                    keepChecking = checkRestartAttempts(BadHostTimeThreshold, BadHostRestartThreshold, "BAD")

            if keepChecking:
                keepChecking = checkRoleBadHealthAttempts()

            logger.debug("Sleeping for "+str(monitoringTimeThreshold)+" minute before re-checking "+str(RoleTypeName)+" status.")
            # Sleep for monitoringTimeThreshold minute's and then again start monitoring 
            time.sleep(60 * monitoringTimeThreshold)
                 
        except ApiException as err:
            logger.error("Error while monitoring retrying iteration after " + str(monitoringTimeThreshold) +  " min error: " + str(err))
            time.sleep(60 * monitoringTimeThreshold)

#-------------------------------------------------------------------------------------------------------------------
def stopRole(clusterName, serviceName, serviceRole):
    #Role list is of the type array
    roleList = [serviceRole]
    curRoleBody = cm_client.ApiRoleNameList(roleList)
    stopped=False
    start_time = datetime.now() #Capture time just before issue of command
    role_commands_resource_api_instance.stop_command(clusterName, serviceName, body=curRoleBody)
    #loop and check if service is stopped
    while stopped == False:
        logger.debug("Checking if service "+ serviceName + " is stopped")
        getRoleInfo()
        logger.debug("Current service role state: " + currentServiceRole.role_state)
        if currentServiceRole.role_state == "STOPPED":
            stopped=True
            break
        time_delta = datetime.now() - start_time
        if time_delta.total_seconds() >= commandTimeOut: #commandTimeOut is defaulted to 120 seconds
            raise RoleStopTimeoutError
        time.sleep(10) #Sleep for ten seconds

#-------------------------------------------------------------------------------------------------------------------
def restartRole(clusterName, serviceName, serviceRole):
    #Role list is of the type array
    roleList = [serviceRole]
    curRoleBody = cm_client.ApiRoleNameList(roleList)
    started=False
    start_time = datetime.now() #Capture time just before issue of command
    response = role_commands_resource_api_instance.restart_command(clusterName, serviceName, body=curRoleBody)
    #loop and check if service is stopped
    while started == False:
        logger.debug("Checking if role "+ serviceRole + " is started")
        getRoleInfo()
        logger.debug("Current service role state: " + currentServiceRole.role_state)
        if currentServiceRole.role_state == "STARTED":
            started=True
            break
        time_delta = datetime.now() - start_time
        if time_delta.total_seconds() >= commandTimeOut: #commandTimeOut is defaulted to 120 seconds
            raise RoleRestartTimeoutError
        time.sleep(10) #Sleep for ten seconds

#-------------------------------------------------------------------------------------------------------------------
def restartService(clusterName, serviceName):
    started=False
    start_time = datetime.now()
    services_resource_api_instance.restart_command(clusterName, serviceName)
    while started == False:
        logger.debug("Checking if service "+ serviceName + " is started")
        getServiceInfo()
        logger.debug("Current service state: " + clusterService.service_state)
        if clusterService.service_state == "STARTED":
            started=True
            break
        time_delta = datetime.now() - start_time
        if time_delta.total_seconds() >= commandTimeOut: #commandTimeOut is defaulted to 120 seconds
            raise ServiceRestartTimeoutError
        time.sleep(10) #Sleep for ten seconds

#-------------------------------------------------------------------------------------------------------------------
def moveService():
    global currentRoleFailCheckCount
    currentRoleFailCheckCount=0 #Reset when service is moved.
    
    logger.info("Starting "+str(RoleTypeName)+" move to new host ")
    logger.info("Move reason " + str(currentServiceRoleHostHealth \
                and "Good "+str(RoleTypeName)+" Host health but reached threshold unexpected exits" \
                or "Bad "+str(RoleTypeName)+" Host health and reached threshold unexpected exits"))
       
    moveReason = str(currentServiceRoleHostHealth \
                and str(RoleTypeName)+" server host is in Good health but unexpected exits reached threshold" \
                or str(RoleTypeName)+" server host is in Bad health and unexpected exits reached threshold")

    # Get latest state for cluster, service and role
    refreshGlobals()

    ########################################################################################################
    # Create a list of available hosts for new service
    logger.debug("Finding new host to move "+str(RoleTypeName)+" to")
    newHosts = [ServicePrimaryHost] + ServiceFailoverHosts
    ServiceCurrentHost = host_resource_api_instance.read_host(currentServiceRole.host_ref.host_id).hostname.encode('utf-8')
    logger.debug("New Hosts: " + str(newHosts))
    logger.debug("ServiceCurrentHosts: " + str(ServiceCurrentHost))
    newHosts.remove(ServiceCurrentHost)
    logger.debug("Possible hosts list: " + str(newHosts))
    
    # Check health for new hosts to find available hosts
    availableNewHosts = []
    #for hostName in api.get_all_hosts():
    hosts = cluster_resource_api_instance.list_hosts(clusterDisplayName)
    for host_ref in hosts.items:
        if host_ref.hostname in newHosts:
            host = host_resource_api_instance.read_host(host_ref.host_id)
            logger.debug("HEALTH SUMMARY: " + host.health_summary)
            if host.health_summary == "GOOD":
                availableNewHosts += [host]
    
    newServiceHost = None
    if availableNewHosts != []:
        logger.debug("Hosts found: " + str([host.hostname for host in availableNewHosts]))
        newServiceHost = availableNewHosts[0]
    
    # Send moving Service email
    SendMail(Mode='Move', moveReason=moveReason, currentHost=ServiceCurrentHost, newHost=(newServiceHost.hostname if newServiceHost != None else 'N/A'))
    
    if newServiceHost == None:
        logger.critical("No available host to relocate "+str(RoleTypeName))
        if sendFailureEmail:
            SendMail(Mode="Failure", failureReason="No available host to relocate "+str(RoleTypeName) , failureErrorMessage="None")
        return 
    
    ########################################################################################################
    # Issue Stop command on current Service role and wait for command to finish
    try:
        logger.info("Stopping current "+str(RoleTypeName)+" role")
        stopRole(clusterDisplayName, clusterService.name, currentServiceRole.name)
    except ApiException as err:
        logger.critical("Failed to stop current "+str(RoleTypeName)+" role > " + str(err))
        if sendFailureEmail:
            SendMail(Mode="Failure", failureReason="Failed to stop current "+str(RoleTypeName)+" role" , failureErrorMessage=str(err))
        return

    ########################################################################################################
    # Delete currentServiceRole role
    try:
        logger.debug("Service Name: " + clusterService.name)
        logger.debug("Role Name: " + currentServiceRole.name)
        logger.info("Deleting current "+str(RoleTypeName)+" role")
        #This cm_client delete_role function is documented, but does not actually work in CDH 6
        #services_resource_api_instance.delete_role(clusterDisplayName, currentServiceRole.name, clusterService.name)
        
        #Instead replacing with pure call to restful API 
        endpoint = roleNameEndpoint.format(clusterName=clusterDisplayName,
                                        serviceName=clusterService.name,
                                        roleName=currentServiceRole.name)
        logger.debug("Calling endpoint: " + endpoint)
        if clouderaManagerHTTPS:
            response = requests.delete(api_url + endpoint, auth = HTTPBasicAuth(clouderaManagerUserName, clouderaManagerPassword), verify=clouderaManagerPEM)
        else:
            response = requests.delete(api_url + endpoint, auth = HTTPBasicAuth(clouderaManagerUserName, clouderaManagerPassword))
        logger.debug("Response status code: "+ str(response.status_code))
        if response.status_code != 200:
            raise Exception("Call to endpoint {e} ended with {v}".format(e=endpoint, v=response.status_code))
    except ApiException as err:
        logger.critical("Failed to delete current "+str(RoleTypeName)+" role > " + str(err))
        if sendFailureEmail:
            SendMail(Mode="Failure", failureReason="Failed to delete current "+str(RoleTypeName)+" role" , failureErrorMessage=str(err))
        return
    
    ########################################################################################################
    # Create new Service role on first host from available host list
    # https://archive.cloudera.com/cm6/6.0.0/generic/jar/cm_api/swagger-html-sdk-docs/python/docs/ServicesResourceApi.html#create_roles
    try:
        if newServiceHost != None:
            role_name = clusterService.name + '-' + RoleType + '-' + str(int(time.time()))
            
            #Create JSON Data from RoleList which is python dictionary
            json_data={"items": [{"name": role_name,"type": RoleType,"hostRef": {"hostId": newServiceHost.host_id}}]}
            logger.debug("Posting JSON Data: " + json.dumps(json_data))
            
            endpoint = rolesEndpoint.format(clusterName=clusterDisplayName,serviceName=clusterService.name)
            final_endpoint = api_url + endpoint
            logger.debug("Endpoint: " + final_endpoint)

            headers = {'Content-Type': 'application/json'}
            if clouderaManagerHTTPS:
                response = requests.post(final_endpoint, auth = HTTPBasicAuth(clouderaManagerUserName, clouderaManagerPassword), headers=headers, data=json.dumps(json_data), verify=clouderaManagerPEM)
            else:
                response = requests.post(final_endpoint, auth = HTTPBasicAuth(clouderaManagerUserName, clouderaManagerPassword), headers=headers, data=json.dumps(json_data))
            logger.debug("Response status code: "+ str(response.status_code))
            
            if response.status_code != 200:
                raise Exception("Call to endpoint {e} ended with {v}".format(e=endpoint, v=response.status_code))
    except ApiException as err:
        logger.critical("Failed to create new "+str(RoleTypeName)+" role > " + str(err))
        if sendFailureEmail:
            SendMail(Mode="Failure", failureReason="Failed to create new "+str(RoleTypeName)+" role " , failureErrorMessage=str(err))
        return

    ########################################################################################################
    # Deploy new client configuration on cluster
    newService = None
    try:
        logger.info("Updating client configuration on cluster")
        #newService = role_cfg_grp_resource_api_instance.read_role_config_group(RoleType)
        config_groups = role_cfg_grp_resource_api_instance.read_role_config_groups(clusterDisplayName, clusterService.name)
        new_config = cm_client.ApiConfigList([{'name': 'unexpected_exits_thresholds', 'value': '{\"warning\":\"never\", \"critical\":\"never\"}'}])
        for config_group in config_groups.items:
            if config_group.role_type == RoleType:
                role_cfg_grp_resource_api_instance.update_config(cluster_name=clusterDisplayName,
                                                                 role_config_group_name=config_group.name,
                                                                 service_name=clusterService.name,
                                                                 body=new_config)
                newService = config_group
        logger.info("Client configuration updated on cluster")

        logger.info("Deploying new client configuration on cluster")
        configDeployCommand = cluster_resource_api_instance.deploy_client_config(cluster_name=clusterDisplayName)
        wait(configDeployCommand, commandTimeOut)
        logger.info("New client configuration deployed on cluster")
    except ApiException as err:
        logger.critical("Failed to deploy new configuration on cluster > " + str(err))
        if sendFailureEmail:
            SendMail(Mode="Failure", failureReason="Failed to deploy new configuration on cluster" , failureErrorMessage=str(err))
        return

    ########################################################################################################
    # Restart the new Service role
    try:
        #refresh the current role service since it has changed
        getRoleInfo()
        logger.info("Restarting current "+str(RoleTypeName)+" role for the service "+clusterService.name+" on cluster "+clusterDisplayName)
        restartRole(clusterDisplayName, clusterService.name, currentServiceRole.name)
    except ApiException as err:
        logger.critical("Failed to restart current "+str(RoleTypeName)+" role > " + str(err))
        if sendFailureEmail:
            SendMail(Mode="Failure", failureReason="Failed to restart current "+str(RoleTypeName)+" role" , failureErrorMessage=str(err))
        return

    ########################################################################################################
    # Restart the entire Impala Service, for other moves this step is skipped
    if ServiceType == "IMPALA":
        try:
            logger.info("Restarting Service "+str(ServiceTypeName))
            restartService(clusterDisplayName, clusterService.name)
            logger.info("The " + str(RoleTypeName) + " service restart command sent with success")
        except ApiException as err:
            logger.critical("Failed to restart service "+str(ServiceTypeName)+" " + str(err))
            if sendFailureEmail:
                SendMail(Mode="Failure", failureReason="Failed to restart "+str(ServiceTypeName)+" " , failureErrorMessage=str(err))
            return

    if sendSuccessEmail:
        SendMail(Mode="Success")
    logger.info(str(RoleTypeName)+" Move to new server completed successfully, waiting for "+str(moveServiceSuccessTimeThreshold)+ " minute(s) before continuing checks.")
    time.sleep(60 * moveServiceSuccessTimeThreshold)

#-------------------------------------------------------------------------------------------------------------------
if __name__ == '__main__':
    # create a process ID file in /var/run/shs2ha
    pid = os.getpid()
    op = open("/var/run/" + PidFileName,"w")
    op.write("%s" % pid)
    op.close()
    
    # Configure authentication
    cm_client.configuration.username = clouderaManagerUserName
    cm_client.configuration.password = clouderaManagerPassword
    clouderaManagerProtocol = "http://" #Default
    if clouderaManagerHTTPS:
        cm_client.configuration.verify_ssl = True
        # Path of truststore file in PEM
        cm_client.configuration.ssl_ca_cert = clouderaManagerPEM
        clouderaManagerProtocol = "https://" #Secure
    
    # Construct base URL for API
    # https://cmhost:7183/api/v30
    api_url = clouderaManagerProtocol + clouderaManagerHost + ':' + str(clouderaManagerPort) + '/api/v' + str(clouderaManagerApiVersion)
    #Setup API Instances we will leveraged throughout the code
    api_client = cm_client.ApiClient(api_url)
    services_resource_api_instance = cm_client.ServicesResourceApi(api_client)
    cluster_resource_api_instance = cm_client.ClustersResourceApi(api_client)
    roles_resource_api_instance = cm_client.RolesResourceApi(api_client)
    mgmt_service_resource_api_instance = cm_client.MgmtServiceResourceApi(api_client)
    time_series_resource_api_instance = cm_client.TimeSeriesResourceApi(api_client)
    host_resource_api_instance = cm_client.HostsResourceApi(api_client)
    role_commands_resource_api_instance = cm_client.RoleCommandsResourceApi(api_client)
    mgmt_roles_resource_api_instance = cm_client.MgmtRolesResourceApi(api_client)
    role_cfg_grp_resource_api_instance = cm_client.RoleConfigGroupsResourceApi(api_client)

    logger.info("Starting script")
    # Get Cloudera manager api handle
    logger.info("Got Client API instance > " + str(api_client))
    # Monitor current status of service and move to new host if required
    while True:
        # Monitor service state based on provided rules 
        monitorService()