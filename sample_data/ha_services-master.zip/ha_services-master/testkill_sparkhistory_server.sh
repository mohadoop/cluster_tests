#!/bin/bash
# sh testkill_sparkhistory_server.sh  6 30
#SPARK_YARN_HISTORY_SERVER is the name to look for in CDH 6.x, no longer SPARK2_YARN_HISTORY_SERVER
re='^[0-9]+$'
echo "Running test kill script"
echo "Script terminates Job history server process"
echo "Process will be killed $1 time in every $2 seconds"
echo "-------------------------------------------------------------------------------"
for counter in $(seq 1 $1)
do
        echo "Starting iteration $counter: $(date)"
        pid=$(ps -Af | grep "SPARK_YARN_HISTORY_SERVER" | grep -v "grep" | awk '{print $2}')
        if ! [[ $pid =~ $re ]] ; then
            echo "Warning!: could not find any active Spark History Server on this iteration, skipping!"
        else
            echo "Found the pid ${pid} related to Spark History Server, killing process"
            kill -9 ${pid}
            echo "Process killed"
        fi
        echo "-------------------------------------------------------------------------------"
        sleep $2
done