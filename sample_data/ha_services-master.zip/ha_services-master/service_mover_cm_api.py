############################################################################################################################################
# File Name: impss_ha.py
# Author: Thomas Kreutzer
# Date created: May 18, 2021
# Date last modified: May 18, 2021
# Python Version: 2.7.5
# CM Python API Version: 14
# Description: Following script is meant to replicate HA functionality for Impala State Store and automatically move it to a new host 
#              and restart Impala. This script is based off the original scripts created by Ashish Tyagi. This script will also add
#              restarting the entire Impala service once a move is done as is required to make it effective.
# Change Log
# Change Number | Date MM-DD-YYYY  | Changed By        | Change Description
# Initial       | 04-13-2017       | Ashish Tyagi      | Initial code draft 
# Initial       | 04-17-2017       | Ashish Tyagi      | Added logging and email alerts 
# Initial       | 05-01-2017       | Ashish Tyagi      | Added secure password reading
# Initial       | 05-18-2021       | Thomas Kreutzer   | Initial code draft for impala state store
#
############################################################################################################################################

import os
import logging
import subprocess
import smtplib
import logging.config
import ConfigParser
import time, datetime
from cm_api.api_client import ApiResource, ApiException
from email.MIMEMultipart import MIMEMultipart
from email.MIMEText import MIMEText
from email.MIMEImage import MIMEImage

# Define constants 
ConfigFilePath = "/opt/cgfiles/common/bin/impss_ha/application.conf"


# Read application.conf file
config = ConfigParser.SafeConfigParser()
config.read(ConfigFilePath)

# Populate required variables from configuration file
clouderaManagerHost = config.get("clouderaManager", "clouderaManagerHost")
clouderaManagerPort = config.getint("clouderaManager", "clouderaManagerPort")
clouderaManagerApiVersion = config.getint("clouderaManager", "clouderaManagerApiVersion")
clouderaManagerHTTPS = config.getboolean("clouderaManager", "clouderaManagerHTTPS")
clouderaManagerUserName = config.get("clouderaManager", "clouderaManagerUserName")
clusterDisplayName = config.get("clouderaManager", "clusterDisplayName")
sendAlertEmail = config.getboolean("alertingService", "sendAlertEmail")
sendSuccessEmail = config.getboolean("alertingService", "sendSuccessEmail")
sendFailureEmail = config.getboolean("alertingService", "sendFailureEmail")
alertEmailIcon = config.get("alertingService", "alertEmailIcon")
alertEmailUseTLS = config.getboolean("alertingService", "alertEmailUseTLS")
alertEmailFromAddress = config.get("alertingService", "alertEmailFromAddress")
alertEmailToAddress = config.get("alertingService", "alertEmailToAddress")
SMTPServerAddress = config.get("alertingService", "SMTPServerAddress")
SMTPServerPort = config.getint("alertingService", "SMTPServerPort")
ServicePrimaryHost = config.get("FailoverServers", "ServicePrimaryHost")
ServiceFailoverHosts = config.get("FailoverServers", "ServiceFailoverHosts").split(',')
GoodHostTimeThreshold = config.getint("FailoverThresholds", "GoodHostTimeThreshold")
BadHostTimeThreshold = config.getint("FailoverThresholds", "BadHostTimeThreshold")
GoodHostRestartThreshold = config.getint("FailoverThresholds", "GoodHostRestartThreshold")
BadHostRestartThreshold = config.getint("FailoverThresholds", "BadHostRestartThreshold")
BadRoleCheckCountThreshold = config.getint("FailoverThresholds", "BadRoleCheckCountThreshold")
monitoringTimeThreshold = config.getint("FailoverScript", "monitoringTimeThreshold")
commandTimeOut = config.getint("FailoverScript", "commandTimeOut")
maintenanceModeCheck = config.getboolean("FailoverScript", "maintenanceModeCheck")
loggingConfigFile = config.get("FailoverScript", "loggingConfigFile")
loggerName = config.get("FailoverScript", "loggerName")
moveServiceSuccessTimeThreshold = config.getint("FailoverScript", "moveServiceSuccessTimeThreshold")
PidFileName = config.get("FailoverScript","PidFileName")
# create a process ID file in /var/run/impssha
ServiceType = config.get("ApiVariables","ServiceType")
RoleType = config.get("ApiVariables","RoleType")
HostHealthCheckName = config.get("ApiVariables","HostHealthCheckName")
ServiceTypeName = config.get("ApiVariables","ServiceTypeName")
RoleTypeName = config.get("ApiVariables","RoleTypeName")


# Get secure passwords for login 
clouderaManagerPasswordMode = config.get("clouderaManager", "clouderaManagerPasswordMode")
clouderaManagerPassword = "admin"
if clouderaManagerPasswordMode == "Command":
    clouderaManagerPasswordCommand = config.get("clouderaManager", "clouderaManagerPassword").split(' ')
    clouderaManagerPassword = subprocess.Popen(clouderaManagerPasswordCommand, stdout=subprocess.PIPE).stdout.read().strip()
elif clouderaManagerPasswordMode == "Plain":
    clouderaManagerPassword = config.get("clouderaManager", "clouderaManagerPassword")
SMTPServerAuthentication = config.getboolean("alertingService", "SMTPServerAuthentication")
if SMTPServerAuthentication:
    SMTPServerPasswordMode = config.get("alertingService", "SMTPServerPasswordMode")
    SMTPServerPassword = "admin"
    if SMTPServerPasswordMode == "Command":
        SMTPServerPasswordCommand = config.get("alertingService", "SMTPServerPassword").split(' ')
        SMTPServerPassword = subprocess.Popen(SMTPServerPasswordCommand, stdout=subprocess.PIPE).stdout.read().strip()
    elif SMTPServerPasswordMode == "Plain":
        SMTPServerPassword = config.get("alertingService", "SMTPServerPassword")

# Enable logging and get logger handle 
logging.config.fileConfig(loggingConfigFile)
logger = logging.getLogger(loggerName)


# Define global variables
api = None
cluster = None
clusterService = None
currentServiceRole = None
currentServiceRoleHostHealth = False
currentRoleFailCheckCount = 0

# Sending email when Service is moved
def SendMail(**kwargs):
    logger.info("Sending " +str(RoleTypeName)+ " " + kwargs['Mode'] +" email")
    try:
        msg = MIMEMultipart('related')
        msg['From'] = alertEmailFromAddress
        msg['Bcc'] = alertEmailToAddress
        msg['Subject'] = "Cluster: " + str(cluster.displayName) +" - " +str(RoleTypeName)+" Server Move (HA)"
        
        if kwargs['Mode'] == 'Move':
            msgText = MIMEText(
                               '<p>' + \
                               'Moving '+ str(RoleTypeName) +' Server to a New Host: <br>' + \
                               '<b>Move Reason:</b><br>' + \
                               kwargs['moveReason'] + '<br>' +\
                               '<b>Cluster Name: '+ str(cluster.displayName)  +'</b><br>' + \
                               '<b>Current ' + str(RoleTypeName) +' Server Host: </b>' + kwargs['currentHost'] + '<br>' + \
                               '<b>New ' + str(RoleTypeName) +' Server Host: </b>' + kwargs['newHost'] + '<br><br>' + \
                               '</br>Possible "Config change: Restart required" alerts can be seen on different services.( <img src="cid:image1"> ) <br>' + \
                               'These alerts seen on CM UI have no impact on the cluster and can be safely ignored.<br>' + \
                               'If anyone happens to have done a purposeful configuration change and saved them, ' + \
                               'then a restart on that particular service or instance would be needed.<br><br>' + \
                               'Thanks,<br>Operations' + \
                               '</p>', \
                               'html')
            msg.attach(msgText)
            img = open(alertEmailIcon, 'rb')
            msgImage = MIMEImage(img.read())
            img.close()
            msgImage.add_header('Content-ID', '<image1>')
            msg.attach(msgImage)
            
        elif kwargs['Mode'] == 'Success':
            msg.attach(MIMEText("Succeeded in moving "+str(RoleTypeName)+" Server to new host", 'plain'))
        elif kwargs['Mode'] == 'Failure':
            msgText = MIMEText('<p>' + \
                               'Failed to move '+str(RoleTypeName)+' Server to new host <br><br>' + \
                               '<b>Failure Reason: </b>' + \
                               kwargs['failureReason'] + '<br>' + \
                               '<b>Error message: </b>' + \
                               kwargs['failureErrorMessage'] + '<br>' + \
                               '</p>','html')
            msg.attach(msgText)
                
        server = smtplib.SMTP(SMTPServerAddress, SMTPServerPort)
        if alertEmailUseTLS:
            server.starttls()
        if SMTPServerAuthentication:
            server.login(alertEmailFromAddress, SMTPServerPassword)
        text = msg.as_string()
        server.sendmail(alertEmailFromAddress, alertEmailToAddress, text)
        server.quit()
    except Exception as err:
        logger.debug("Error sending email: " + str(err)) 


# Refreshes state for global variables representing cluster, service and role
def refreshGlobals():
    logger.debug("Refreshing handles")
    global cluster
    global clusterService
    global currentServiceRole
    try:
        logger.debug("Getting cluster handle")
        # Get required cluster
        cluster = api.get_cluster(clusterDisplayName)
        # Get service
        logger.debug("Getting "+str(ServiceTypeName)+" service handle")
        for service in cluster.get_all_services():
            if service.type == ServiceType:
                clusterService = service
                break
        # Get current Server   
        logger.debug("Getting current "+str(RoleTypeName)+" role handle")
        for serviceRole in clusterService.get_all_roles():
            if serviceRole.type == RoleType:
                currentServiceRole = serviceRole
                break
    except ApiException as err:
        logger.error("Failed to refresh handles > " + str(err))

def checkRestartAttempts(hostTimeThreshold, hostRestartThreshold, hostHealth):
    logger.debug("Current "+str(RoleTypeName)+" host health is "+hostHealth+" checking last " + \
             str(hostTimeThreshold) + \
             " minute(s) of data to check if number of restart attempts are " + \
             str(hostRestartThreshold) + " or more")
    
    from_time = datetime.datetime.fromtimestamp(time.time() - (60 * hostTimeThreshold)) 
    to_time = datetime.datetime.fromtimestamp(time.time())
    query = "SELECT sum(integral(unexpected_exits_rate)) WHERE roleType = " +  RoleType + " AND clusterDisplayName = '" + clusterDisplayName + "'"
    logger.debug("query is " + query)
    timeSeriesResult = api.query_timeseries(query, from_time, to_time)
    numberOfRestarts = 0.0
    for timeSeries in timeSeriesResult[0].timeSeries:
        for point in timeSeries.data:
            numberOfRestarts = point.value / 60
            logger.debug("numberOfRestarts= " + str(numberOfRestarts))
    if numberOfRestarts < hostRestartThreshold:
        logger.debug("Current value under threshold skipping this iteration: " + str(numberOfRestarts))
        return True #Keep checking
    else:
        logger.info("Current value above threshold initiating "+str(RoleTypeName)+" move to new host")
        moveService()
        return False #Do not check next step as we just moved the service

def checkRoleBadHealthAttempts():
    global currentRoleFailCheckCount
    logger.debug("Current "+str(RoleTypeName)+" role health is BAD count " + \
                 str(currentRoleFailCheckCount) + \
                 " times for the threshold " + str(BadRoleCheckCountThreshold) + \
                 " checking every " +str(monitoringTimeThreshold)+ " minute(s)." )
    
    from_time = datetime.datetime.fromtimestamp(time.time() - (60 * BadHostTimeThreshold))
    to_time = datetime.datetime.fromtimestamp(time.time())
    query = "SELECT health_bad_rate WHERE roleType = " +  RoleType + " AND clusterDisplayName = '" + clusterDisplayName + "'"
    logger.debug("query is " + query)
    timeSeriesResult = api.query_timeseries(query, from_time, to_time)
    for timeSeries in timeSeriesResult[0].timeSeries:
        #logger.debug("timeSeries: " + str(timeSeries))
        for point in timeSeries.data:
            finalVal = 0
            if point.value > finalVal:
                finalVal = point.value
    if finalVal > 0:
        currentRoleFailCheckCount +=1
    if finalVal == 0: #If it is 0, we should reset as we do not want to keep the count if self-corrects
        currentRoleFailCheckCount=0
    
    #finally check if we exceed bad count
    if currentRoleFailCheckCount < BadRoleCheckCountThreshold:
        logger.debug("Current value "+str(currentRoleFailCheckCount)+" under threshold "+str(BadRoleCheckCountThreshold)+" skipping this iteration")
        return True #Keep checking
    else:
        logger.info("Current value above threshold initiating "+str(RoleTypeName)+" move to new host")
        moveService()
        return False #Do not check next step as we just moved the service

def monitorService():
    global currentServiceRoleHostHealth
    global currentServiceRoleHealth
    global currentRoleFailCheckCount
    logger.info("Starting monitoring")
    while True:
        logger.info("Starting next monitoring iteration")
        try:
            # Get latest state for cluster, service and role
            refreshGlobals()
            logger.debug("Getting running command list for cluster and "+str(RoleTypeName)+" service")
            clusterCommands = cluster.get_commands()
            serviceCommands = clusterService.get_commands()
            
            # Check Service host's health
            logger.debug("Checking current "+str(RoleTypeName)+" host health")
            currentServiceRoleHostHealth = False
            for check in currentServiceRole.healthChecks:
                if check['name'] == HostHealthCheckName and check['summary'] == 'GOOD':
                    currentServiceRoleHostHealth = True
                    break
            logger.debug("Current "+str(RoleTypeName)+" server 'host' health: " + str(currentServiceRoleHostHealth and "Good" or "Bad") 
                         + " - the service itself may still be down regardless of host health.")
            
            # Check if Service is up and running normally
            logger.debug("Checking current "+str(RoleTypeName)+" status")
            currentServiceRoleHealth = False
            if "entityStatus" in currentServiceRole._ATTRIBUTES:
                if currentServiceRole.entityStatus == "GOOD_HEALTH":
                    currentServiceRoleHealth = True
            else:
                logger.debug("EntityStatus not found using Health Summary instead")
                if currentServiceRole.healthSummary == "GOOD":
                    currentServiceRoleHealth = True
            logger.debug("Current "+str(RoleTypeName)+" status: " + str(currentServiceRoleHealth and "Good" or "Bad"))
            
            #Run a series of checks, if preceding is flagged false, stop checking further.
            keepChecking = True
            # Check if cluster is in maintenance mode or stopped
            logger.debug("Checking if cluster or "+ str(RoleTypeName) +" is in maintenance mode or there are any commands running on them")
            if maintenanceModeCheck and cluster.maintenanceMode:
                keepChecking=False
                logger.debug("Cluster in maintenance mode skipping further checks")
            
            # Check if cluster is stopped or is stopping
            if keepChecking:
                if cluster.entityStatus in ["STOPPING", "STOPPED"]:
                    keepChecking = False
                    logger.debug("Cluster in currently stopped skipping further checks")
            
            # Check if cluster is running any command right now
            if keepChecking:
                if len(clusterCommands) != 0 and clusterCommands[0].name in ["Start","Restart","Stop"]:
                    keepChecking = False
                    logger.debug("There are running commands on cluster skipping further checks")
            
            # Check if service is in maintenance mode or stopped
            if keepChecking:
                if maintenanceModeCheck and clusterService.maintenanceMode:
                    keepChecking = False
                    logger.debug(str(RoleTypeName) +" service is in maintenance mode skipping further checks")
            
            # Check if service is stopped or is stopping
            if keepChecking:
                if clusterService.serviceState in ["STOPPING", "STOPPED"]:
                    keepChecking = True
                    logger.debug(str(RoleTypeName) +" service is currently stopped skipping further checks")
            
            # Check if cluster is running any command right now
            if keepChecking:
                if len(serviceCommands) != 0 and serviceCommands[0].name in ["Start","Restart","Stop"]:
                    keepChecking = True
                    logger.debug("There are running commands on "+str(RoleTypeName)+" service skipping further checks")
            
            # Check last Good/Bad HostTimeThreshold min of time series data
            # to see number or restart attempts 
            # if more than Good/Bad HostRestartThreshold move the Service.
            if keepChecking:
                if currentServiceRoleHostHealth: #If host health is good
                    keepChecking = checkRestartAttempts(GoodHostTimeThreshold, GoodHostRestartThreshold, "GOOD")
                else: #If host health is bad
                    keepChecking = checkRestartAttempts(BadHostTimeThreshold, BadHostRestartThreshold, "BAD")

            if keepChecking:
                keepChecking = checkRoleBadHealthAttempts()

            logger.debug("Sleeping for "+str(monitoringTimeThreshold)+" minute before re-checking "+str(RoleTypeName)+" status.")
            # Sleep for monitoringTimeThreshold minute's and then again start monitoring 
            time.sleep(60 * monitoringTimeThreshold)
                 
        except ApiException as err:
            logger.error("Error while monitoring retrying iteration after " + str(monitoringTimeThreshold) +  " min error: " + str(err))
            time.sleep(60 * monitoringTimeThreshold)

def moveService():
    global currentRoleFailCheckCount
    currentRoleFailCheckCount=0 #Reset when service is moved.
    
    logger.info("Starting "+str(RoleTypeName)+" move to new host ")
    logger.info("Move reason " + str(currentServiceRoleHostHealth \
                and "Good "+str(RoleTypeName)+" Host health but reached threshold unexpected exits" \
                or "Bad "+str(RoleTypeName)+" Host health and reached threshold unexpected exits"))
       
    moveReason = str(currentServiceRoleHostHealth \
                and str(RoleTypeName)+" server host is in Good health but unexpected exits reached threshold" \
                or str(RoleTypeName)+" server host is in Bad health and unexpected exits reached threshold")  

    # Get latest state for cluster, service and role
    refreshGlobals()

    # Create a list of available hosts for new service
    logger.debug("Finding new host to move "+str(RoleTypeName)+" to")
    newHosts = [ServicePrimaryHost] + ServiceFailoverHosts
    ServiceCurrentHost = api.get_host(currentServiceRole.hostRef.hostId).hostname.encode('utf-8')
    newHosts.remove(ServiceCurrentHost)
    logger.debug("Possible hosts list: " + str(newHosts))
    
    # Check health for new hosts to find available hosts
    availableNewHosts = [] 
    for hostName in api.get_all_hosts():
        if hostName.hostname in newHosts:
            host = api.get_host(hostName.hostId)
            if host.healthSummary == "GOOD":
                availableNewHosts += [host]
    
    newnewServiceHostHost = None
    if availableNewHosts != []:
        logger.debug("Hosts found: " + str([host.hostname for host in availableNewHosts]))
        newServiceHost = availableNewHosts[0]
    
    # Send moving Service email
    SendMail(Mode='Move', moveReason=moveReason, currentHost=ServiceCurrentHost, newHost=(newServiceHost.hostname if newServiceHost != None else 'N/A'))
    
    if newServiceHost == None:
        logger.critical("No available host to relocate "+str(RoleTypeName))
        if sendFailureEmail:
            SendMail(Mode="Failure", failureReason="No available host to relocate "+str(RoleTypeName) , failureErrorMessage="None")
        return 
    
    # Issue Stop command on current Service role and wait for command to finish
    try:
        logger.info("Stopping current "+str(RoleTypeName)+" role")
        stopCommand = clusterService.stop_roles(currentServiceRole.name)
        stopCommand[0].wait(commandTimeOut)
    except ApiException as err:
        logger.critical("Failed to stop current "+str(RoleTypeName)+" role > " + str(err))
        if sendFailureEmail:
            SendMail(Mode="Failure", failureReason="Failed to stop current "+str(RoleTypeName)+" role" , failureErrorMessage=str(err))
        return 
    
    # Delete currentServiceRole role 
    try: 
        logger.info("Deleting current "+str(RoleTypeName)+" role")
        clusterService.delete_role(currentServiceRole.name)
    except ApiException as err:
        logger.critical("Failed to delete current "+str(RoleTypeName)+" role > " + str(err))
        if sendFailureEmail:
            SendMail(Mode="Failure", failureReason="Failed to delete current "+str(RoleTypeName)+" role" , failureErrorMessage=str(err))
        return
    
    # Create new Service role on first host from available host list 
    newService = None
    try:
        if newServiceHost != None:
            logger.info("Moving "+str(RoleTypeName)+" to new host: " + newServiceHost.hostname)
            newService = clusterService.create_role( clusterService.name + '-' + RoleType + '-' + str(int(time.time())),
                                              RoleType, 
                                              newServiceHost.hostId)
    except ApiException as err:
        logger.critical("Failed to create new "+str(RoleTypeName)+" role > " + str(err))
        if sendFailureEmail:
            SendMail(Mode="Failure", failureReason="Failed to create new "+str(RoleTypeName)+" role " , failureErrorMessage=str(err))
        return
    
    # Deploy new client configuration on cluster
    try:
        logger.info("Deploying new client configuration on cluster")
        newService.update_config({'unexpected_exits_thresholds':'{"warning":"never","critical":"never"}'})
        configDeployCommand = cluster.deploy_client_config()
        configDeployCommand.wait(commandTimeOut)
    except ApiException as err:
        logger.critical("Failed to deploy new configuration on cluster > " + str(err))
        if sendFailureEmail:
            SendMail(Mode="Failure", failureReason="Failed to deploy new configuration on cluster" , failureErrorMessage=str(err))
        return
    
    # Restart the new Service role
    try:
        logger.info("Starting new "+str(RoleTypeName))
        restartCommand = clusterService.restart_roles(newService.name)
        restartCommand[0].wait(commandTimeOut)
        logger.info(str(RoleTypeName) + " started successfully!")
    except ApiException as err:
        logger.critical("Failed to restart new "+str(RoleTypeName)+" Server > " + str(err))
        if sendFailureEmail:
            SendMail(Mode="Failure", failureReason="Failed to restart new "+str(RoleTypeName)+" Server" , failureErrorMessage=str(err))
        return
    
    # Restart the entire Impala Service, for other moves this step is skipped
    if ServiceType == "IMPALA":
        try:
            logger.info("Restarting Service "+str(ServiceTypeName))
            clusterService.restart().wait(commandTimeOut)
            logger.info("The " + str(RoleTypeName) + " service restart command sent with success")
        except ApiException as err:
            logger.critical("Failed to restart service "+str(ServiceTypeName)+" " + str(err))
            if sendFailureEmail:
                SendMail(Mode="Failure", failureReason="Failed to restart "+str(ServiceTypeName)+" " , failureErrorMessage=str(err))
            return

    if sendSuccessEmail:
        SendMail(Mode="Success")
    logger.info(str(RoleTypeName)+" Move to new server completed successfully, waiting for "+str(moveServiceSuccessTimeThreshold)+ " minute(s) before continuing checks.")
    time.sleep(60 * moveServiceSuccessTimeThreshold)

if __name__ == '__main__':
    # create a process ID file in /var/run/shs2ha
    pid = os.getpid()
    op = open("/var/run/" + PidFileName,"w")
    op.write("%s" % pid)
    op.close()

    logger.info("Starting script")
    # Get Cloudera manager api handle
    api = ApiResource(clouderaManagerHost, clouderaManagerPort, clouderaManagerUserName, clouderaManagerPassword, clouderaManagerHTTPS, clouderaManagerApiVersion)
    logger.info("Got API instance > " + str(api))
    # Monitor current status of service and move to new host if required
    while True:
        # Monitor service state based on provided rules 
        monitorService()